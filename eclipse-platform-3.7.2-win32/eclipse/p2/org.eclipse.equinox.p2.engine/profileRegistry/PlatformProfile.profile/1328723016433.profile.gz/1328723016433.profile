<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='PlatformProfile' timestamp='1328723016433'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.installFolder' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse'/>
    <property name='org.eclipse.equinox.p2.cache' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
  </properties>
</profile>
