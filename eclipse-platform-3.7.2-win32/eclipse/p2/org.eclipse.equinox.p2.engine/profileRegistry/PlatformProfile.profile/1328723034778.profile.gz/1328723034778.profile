<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='PlatformProfile' timestamp='1328723034778'>
  <properties size='6'>
    <property name='org.eclipse.equinox.p2.installFolder' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse'/>
    <property name='org.eclipse.equinox.p2.cache' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='true'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.nl=en_US,osgi.ws=win32,osgi.arch=x86,osgi.os=win32'/>
    <property name='eclipse.touchpoint.launcherName' value='eclipse'/>
  </properties>
  <units size='190'>
    <unit id='a.jre.javase' version='1.6.0' singleton='false'>
      <provides size='159'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' version='1.6.0'/>
        <provided namespace='java.package' name='javax.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.activity' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.annotation.processing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.interfaces' version='0.0.0'/>
        <provided namespace='java.package' name='javax.crypto.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.bmp' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.plugins.jpeg' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.imageio.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.jws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.element' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.type' version='0.0.0'/>
        <provided namespace='java.package' name='javax.lang.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.loading' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.modelmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.monitor' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.openmbean' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.relation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.remote.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.management.timer' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.directory' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.ldap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.naming.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net' version='0.0.0'/>
        <provided namespace='java.package' name='javax.net.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.attribute.standard' version='0.0.0'/>
        <provided namespace='java.package' name='javax.print.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='javax.rmi.ssl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.script' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.callback' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.kerberos' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.login' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.auth.x500' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.cert' version='0.0.0'/>
        <provided namespace='java.package' name='javax.security.sasl' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.midi.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sound.sampled.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.serial' version='0.0.0'/>
        <provided namespace='java.package' name='javax.sql.rowset.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.border' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.colorchooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.event' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.filechooser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.basic' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.metal' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.multi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.plaf.synth' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.table' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.html.parser' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.text.rtf' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.tree' version='0.0.0'/>
        <provided namespace='java.package' name='javax.swing.undo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.tools' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction' version='0.0.0'/>
        <provided namespace='java.package' name='javax.transaction.xa' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.annotation.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.attachment' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.bind.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.keyinfo' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.crypto.dsig.spec' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.datatype' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.namespace' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.parsers' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.events' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.stream.util' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.dom' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.sax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stax' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.transform.stream' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.validation' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.handler.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.http' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.soap' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.spi' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.ws.wsaddressing' version='0.0.0'/>
        <provided namespace='java.package' name='javax.xml.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.ietf.jgss' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA_2_3.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.ORBPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CORBA.TypeCodePackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextExtPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.CosNaming.NamingContextPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.DynamicAny.DynAnyPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecFactoryPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.IOP.CodecPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.Messaging' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableInterceptor.ORBInitInfoPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.CurrentPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAManagerPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.POAPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.portable' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.PortableServer.ServantLocatorPackage' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.SendingContext' version='0.0.0'/>
        <provided namespace='java.package' name='org.omg.stub.java.rmi' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.bootstrap' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.css' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ls' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.ranges' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.stylesheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.traversal' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.w3c.dom.xpath' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.ext' version='0.0.0'/>
        <provided namespace='java.package' name='org.xml.sax.helpers' version='0.0.0'/>
      </provides>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
    </unit>
    <unit id='com.ibm.icu' version='4.4.2.v20110823'>
      <update id='com.ibm.icu' range='[0.0.0,4.4.2.v20110823)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='International Components for Unicode for Java (ICU4J)'/>
        <property name='df_LT.providerName' value='IBM Corporation'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' version='4.4.2.v20110823'/>
        <provided namespace='osgi.bundle' name='com.ibm.icu' version='4.4.2.v20110823'/>
        <provided namespace='java.package' name='com.ibm.icu.lang' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.math' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.text' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.util' version='4.4.2.2'/>
        <provided namespace='java.package' name='com.ibm.icu.impl' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.brkitr' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.coll' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.curr' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.lang' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.rbnf' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.region' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.translit' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.data.icudt44b.zone' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.duration' version='0.0.0'/>
        <provided namespace='java.package' name='com.ibm.icu.impl.locale' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.ibm.icu' version='4.4.2.v20110823'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.ibm.icu; singleton:=true&#xA;Bundle-Version: 4.4.2.v20110823
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='com.jcraft.jsch' version='0.1.44.v201101211721' singleton='false'>
      <update id='com.jcraft.jsch' range='[0.0.0,0.1.44.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.venderName' value='JCraft, Inc.'/>
        <property name='df_LT.bundleName' value='JSch'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%venderName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' version='0.1.44.v201101211721'/>
        <provided namespace='osgi.bundle' name='com.jcraft.jsch' version='0.1.44.v201101211721'/>
        <provided namespace='java.package' name='com.jcraft.jsch' version='0.1.44'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jce' version='0.1.44'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jcraft' version='0.1.44'/>
        <provided namespace='java.package' name='com.jcraft.jsch.jgss' version='0.1.44'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='com.jcraft.jsch' version='0.1.44.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: com.jcraft.jsch&#xA;Bundle-Version: 0.1.44.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='config.a.jre.javase' version='1.6.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' version='1.6.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='1.6.0'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='install'>

          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.servlet' version='2.5.0.v201103041518' singleton='false'>
      <update id='javax.servlet' range='[0.0.0,2.5.0.v201103041518)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Servlet API Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' version='2.5.0.v201103041518'/>
        <provided namespace='osgi.bundle' name='javax.servlet' version='2.5.0.v201103041518'/>
        <provided namespace='java.package' name='javax.servlet' version='2.5.0'/>
        <provided namespace='java.package' name='javax.servlet.http' version='2.5.0'/>
        <provided namespace='java.package' name='javax.servlet.resources' version='2.5.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.servlet' version='2.5.0.v201103041518'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.servlet&#xA;Bundle-Version: 2.5.0.v201103041518
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='javax.servlet.jsp' version='2.0.0.v201101211617' singleton='false'>
      <update id='javax.servlet.jsp' range='[0.0.0,2.0.0.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Java Server Pages API Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='javax.servlet.jsp' version='2.0.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='javax.servlet.jsp' version='2.0.0.v201101211617'/>
        <provided namespace='java.package' name='javax.servlet.jsp' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.el' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.resources' version='2.0.0'/>
        <provided namespace='java.package' name='javax.servlet.jsp.tagext' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.resources' range='2.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='javax.servlet.jsp' version='2.0.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: javax.servlet.jsp&#xA;Bundle-Version: 2.0.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.ant' version='1.8.2.v20120109-1030' singleton='false'>
      <update id='org.apache.ant' range='[0.0.0,1.8.2.v20120109-1030)' severity='0'/>
      <properties size='4'>
        <property name='df_LT.Bundle-Name' value='Apache Ant'/>
        <property name='df_LT.Bundle-Vendor' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%Bundle-Name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Bundle-Vendor'/>
      </properties>
      <provides size='74'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' version='1.8.2.v20120109-1030'/>
        <provided namespace='osgi.bundle' name='org.apache.ant' version='1.8.2.v20120109-1030'/>
        <provided namespace='java.package' name='org.apache.tools.ant' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.dispatch' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.filters' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.filters.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.helper' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.input' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.listener' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.compilers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.condition' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.cvslib' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.email' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ccm' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.clearcase' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.depend.constantpool' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ejb' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.extension.resolvers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.i18n' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.j2ee' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.javacc' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.javah' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jdepend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jlink' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jsp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.jsp.compilers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.junit' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.native2ascii' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.perforce' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.pvcs' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.script' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.sos' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.sound' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.ssh' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.unix' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.vss' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.optional.windows' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.taskdefs.rmic' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.mappers' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.optional.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources.comparators' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.resources.selectors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.selectors' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.selectors.modifiedselector' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.types.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.depend' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.depend.bcel' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.facade' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.java15' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.optional' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.ant.util.regexp' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.bzip2' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.mail' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.tar' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.tools.zip' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.ant' version='1.8.2.v20120109-1030'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='zipped'>
            true
          </instruction>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.ant&#xA;Bundle-Version: 1.8.2.v20120109-1030
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.codec' version='1.3.0.v201101211617' singleton='false'>
      <update id='org.apache.commons.codec' range='[0.0.0,1.3.0.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Codec Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' version='1.3.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.codec' version='1.3.0.v201101211617'/>
        <provided namespace='java.package' name='org.apache.commons.codec' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.binary' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.digest' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.language' version='1.3.0'/>
        <provided namespace='java.package' name='org.apache.commons.codec.net' version='1.3.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.codec' version='1.3.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.codec&#xA;Bundle-Version: 1.3.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.el' version='1.0.0.v201101211617' singleton='false'>
      <update id='org.apache.commons.el' range='[0.0.0,1.0.0.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Apache Commons JSP 2.0 Expression Language Interpreter'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.el' version='1.0.0.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.el' version='1.0.0.v201101211617'/>
        <provided namespace='java.package' name='org.apache.commons.el' version='1.0.0'/>
        <provided namespace='java.package' name='org.apache.commons.el.parser' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.el' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.resources' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.tagext' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.resources' range='[2.4.0,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.el' version='1.0.0.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.el&#xA;Bundle-Version: 1.0.0.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.httpclient' version='3.1.0.v201012070820' singleton='false'>
      <update id='org.apache.commons.httpclient' range='[0.0.0,3.1.0.v201012070820)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Httpclient'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.auth' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.cookie' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.methods.multipart' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.params' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.protocol' version='3.1.0'/>
        <provided namespace='java.package' name='org.apache.commons.httpclient.util' version='3.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='javax.net' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.commons.codec' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.binary' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.codec.net' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.0.4,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.httpclient' version='3.1.0.v201012070820'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.httpclient&#xA;Bundle-Version: 3.1.0.v201012070820
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.commons.logging' version='1.0.4.v201101211617' singleton='false'>
      <update id='org.apache.commons.logging' range='[0.0.0,1.0.4.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse Orbit'/>
        <property name='df_LT.bundleName' value='Apache Commons Logging Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' version='1.0.4.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.commons.logging' version='1.0.4.v201101211617'/>
        <provided namespace='java.package' name='org.apache.commons.logging' version='1.0.4'/>
        <provided namespace='java.package' name='org.apache.commons.logging.impl' version='1.0.4'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.commons.logging' version='1.0.4.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.commons.logging&#xA;Bundle-Version: 1.0.4.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.jasper' version='5.5.17.v201101211617' singleton='false'>
      <update id='org.apache.jasper' range='[0.0.0,5.5.17.v201101211617)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleProvider' value='Eclipse.org'/>
        <property name='df_LT.bundleName' value='Apache Jasper 2 Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.jasper' version='5.5.17.v201101211617'/>
        <provided namespace='osgi.bundle' name='org.apache.jasper' version='5.5.17.v201101211617'/>
        <provided namespace='java.package' name='org.apache.jasper' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.compiler' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.compiler.tagplugin' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.resources' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.runtime' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.security' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.servlet' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.tagplugins.jstl' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.tagplugins.jstl.core' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.util' version='5.5.17'/>
        <provided namespace='java.package' name='org.apache.jasper.xmlparser' version='5.5.17'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.el' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.resources' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp.tagext' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='javax.servlet.resources' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.el' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.commons.logging' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.apache.tools.ant' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.taskdefs' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.types' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.apache.tools.ant.util' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.jasper' version='5.5.17.v201101211617'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.jasper&#xA;Bundle-Version: 5.5.17.v201101211617
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Apache Lucene'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.standard' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.tokenattributes' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.document' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.index' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.messages' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.queryParser' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.function' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.spans' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.store' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util.cache' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.apache.lucene.core' range='[2.9.1,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.analysis' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.highlighter' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.memory' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.queries' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.snowball' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.spellchecker' range='[2.9.1,3.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.misc' range='[2.9.1,3.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene.analysis' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene.analysis' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginName' value='Apache Lucene Analysis'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='26'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ar' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.br' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cjk' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cn' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.compound' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.compound.hyphenation' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.cz' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.de' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.el' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.fa' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.fr' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.miscellaneous' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ngram' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.nl' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.position' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.query' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.reverse' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.ru' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.shingle' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.sinks' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.th' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.apache.lucene.core' range='[2.9.1,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene.analysis' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene.analysis&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.apache.lucene.core' version='2.9.1.v201101211721' singleton='false'>
      <update id='org.apache.lucene.core' range='[0.0.0,2.9.1.v201101211721)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundle.name' value='Apache Lucene Core'/>
        <property name='df_LT.provider.name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundle.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider.name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.core' version='2.9.1.v201101211721'/>
        <provided namespace='osgi.bundle' name='org.apache.lucene.core' version='2.9.1.v201101211721'/>
        <provided namespace='java.package' name='org.apache.lucene' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.standard' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.analysis.tokenattributes' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.document' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.index' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.messages' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.queryParser' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.function' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.payloads' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.search.spans' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.store' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util' version='2.9.1'/>
        <provided namespace='java.package' name='org.apache.lucene.util.cache' version='2.9.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.apache.lucene.core' version='2.9.1.v201101211721'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.apache.lucene.core&#xA;Bundle-Version: 2.9.1.v201101211721
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ant.core' version='3.2.302.v20120110-1739'>
      <update id='org.eclipse.ant.core' range='[0.0.0,3.2.302.v20120110-1739)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Ant Build Tool Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
        <provided namespace='java.package' name='org.eclipse.ant.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ant.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ant.internal.core.contentDescriber' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ant.core' version='3.2.302.v20120110-1739'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ant.core; singleton:=true&#xA;Bundle-Version: 3.2.302.v20120110-1739
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'>
      <update id='org.eclipse.compare' range='[0.0.0,3.5.202.R37x_v20111109-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Compare Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
        <provided namespace='java.package' name='org.eclipse.compare' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.contentmergeviewer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.merge' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.structuremergeviewer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare.core' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.compare' version='3.5.202.R37x_v20111109-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.compare; singleton:=true&#xA;Bundle-Version: 3.5.202.R37x_v20111109-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.compare.core' version='3.5.200.I20110208-0800' singleton='false'>
      <update id='org.eclipse.compare.core' range='[0.0.0,3.5.200.I20110208-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Compare Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.core.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.compare.rangedifferencer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.6.1'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='3.6.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.compare.core' version='3.5.200.I20110208-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.compare.core&#xA;Bundle-Version: 3.5.200.I20110208-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.compare.win32' version='1.0.200.I20110510-0800'>
      <update id='org.eclipse.compare.win32' range='[0.0.0,1.0.200.I20110510-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Compare Support for Word'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.win32' version='1.0.200.I20110510-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.compare.win32' version='1.0.200.I20110510-0800'/>
        <provided namespace='java.package' name='org.eclipse.compare.internal.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
      </requires>
      <filter>
        (osgi.os=win32)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.compare.win32' version='1.0.200.I20110510-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.compare.win32;singleton:=true&#xA;Bundle-Version: 1.0.200.I20110510-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.boot' version='3.1.200.v20100505' singleton='false'>
      <update id='org.eclipse.core.boot' range='[0.0.0,3.1.200.v20100505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Boot'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.boot' version='3.1.200.v20100505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.boot' version='3.1.200.v20100505'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.boot' version='3.1.200.v20100505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.boot&#xA;Bundle-Version: 3.1.200.v20100505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.commands' version='3.6.0.I20110111-0800' singleton='false'>
      <update id='org.eclipse.core.commands' range='[0.0.0,3.6.0.I20110111-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Commands'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.common' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.commands.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.commands.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.commands' version='3.6.0.I20110111-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.commands&#xA;Bundle-Version: 3.6.0.I20110111-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'>
      <update id='org.eclipse.core.contenttype' range='[0.0.0,3.4.100.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Content Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.content' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.content' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.ext' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.contenttype' version='3.4.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.contenttype; singleton:=true&#xA;Bundle-Version: 3.4.100.v20110423-0524
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding' version='1.4.0.I20110111-0800' singleton='false'>
      <update id='org.eclipse.core.databinding' range='[0.0.0,1.4.0.I20110111-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.validation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.conversion' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.validation' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.math' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding' version='1.4.0.I20110111-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding&#xA;Bundle-Version: 1.4.0.I20110111-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.beans' version='1.2.100.I20100824-0800' singleton='false'>
      <update id='org.eclipse.core.databinding.beans' range='[0.0.0,1.2.100.I20100824-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding for JavaBeans'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans' version='1.2.100.I20100824-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.beans' version='1.2.100.I20100824-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.beans' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.beans' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.beans' version='1.2.100.I20100824-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.beans&#xA;Bundle-Version: 1.2.100.I20100824-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800' singleton='false'>
      <update id='org.eclipse.core.databinding.observable' range='[0.0.0,1.4.0.I20110222-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding Observables'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.observable.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.observable.masterdetail' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.observable' version='1.4.0.I20110222-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.observable&#xA;Bundle-Version: 1.4.0.I20110222-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800' singleton='false'>
      <update id='org.eclipse.core.databinding.property' range='[0.0.0,1.4.0.I20110222-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.databinding.property.value' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.list' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.map' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.set' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.databinding.property.value' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.databinding.property' version='1.4.0.I20110222-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.databinding.property&#xA;Bundle-Version: 1.4.0.I20110222-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.expressions' version='3.4.300.v20110228'>
      <update id='org.eclipse.core.expressions' range='[0.0.0,3.4.300.v20110228)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Expression Language'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
        <provided namespace='java.package' name='org.eclipse.core.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.expressions.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.expressions' version='3.4.300.v20110228'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.expressions; singleton:=true&#xA;Bundle-Version: 3.4.300.v20110228
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.externaltools' version='1.0.100.v20111007_r372'>
      <update id='org.eclipse.core.externaltools' range='[0.0.0,1.0.100.v20111007_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='External Tools Headless Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.externaltools' version='1.0.100.v20111007_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.externaltools' version='1.0.100.v20111007_r372'/>
        <provided namespace='java.package' name='org.eclipse.core.externaltools.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.externaltools.internal.launchConfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.externaltools.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.externaltools.internal.registry' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.externaltools' version='1.0.100.v20111007_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.externaltools;singleton:=true&#xA;Bundle-Version: 1.0.100.v20111007_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'>
      <update id='org.eclipse.core.filebuffers' range='[0.0.0,3.5.200.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='File Buffers'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filebuffers.manipulation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filebuffers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filebuffers' version='3.5.200.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filebuffers; singleton:=true&#xA;Bundle-Version: 3.5.200.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'>
      <update id='org.eclipse.core.filesystem' range='[0.0.0,1.3.100.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core File Systems'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.filesystem.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.filesystem.local' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem' version='1.3.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem; singleton:=true&#xA;Bundle-Version: 1.3.100.v20110423-0524
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'>
      <update id='org.eclipse.core.filesystem.win32.x86' range='[0.0.0,1.1.300.v20110423-0524)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Core File System for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.filesystem' version='1.1.300.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.filesystem.win32.x86' version='1.1.300.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.filesystem.win32.x86; singleton:=true&#xA;Bundle-Version: 1.1.300.v20110423-0524&#xA;Fragment-Host: org.eclipse.core.filesystem;bundle-version=&quot;[1.1.0,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'>
      <update id='org.eclipse.core.jobs' range='[0.0.0,3.5.101.v20120113-1953)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Jobs Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.jobs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.jobs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.jobs' version='3.5.101.v20120113-1953'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.jobs; singleton:=true&#xA;Bundle-Version: 3.5.101.v20120113-1953
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.net' version='1.2.100.I20110511-0800'>
      <update id='org.eclipse.core.net' range='[0.0.0,1.2.100.I20110511-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.PLUGIN_NAME' value='Internet Connection Management'/>
        <property name='df_LT.PLUGIN_PROVIDER' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%PLUGIN_NAME'/>
        <property name='org.eclipse.equinox.p2.provider' value='%PLUGIN_PROVIDER'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' version='1.2.100.I20110511-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.net' version='1.2.100.I20110511-0800'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.net.proxy' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='3.2.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.4.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.net' version='1.2.100.I20110511-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.net;singleton:=true&#xA;Bundle-Version: 1.2.100.I20110511-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.net.win32.x86' version='1.0.100.I20110331-0827'>
      <update id='org.eclipse.core.net.win32.x86' range='[0.0.0,1.0.100.I20110331-0827)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Proxy for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86' version='1.0.100.I20110331-0827'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.net.win32.x86' version='1.0.100.I20110331-0827'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.net' version='1.0.100.I20110331-0827'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='1.1.0'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.net.win32.x86' version='1.0.100.I20110331-0827'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.net.win32.x86;singleton:=true&#xA;Bundle-Version: 1.0.100.I20110331-0827&#xA;Fragment-Host: org.eclipse.core.net;bundle-version=&quot;1.1.0&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources' version='3.7.101.v20120125-1505'>
      <update id='org.eclipse.core.resources' range='[0.0.0,3.7.101.v20120125-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Resource Management'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='22'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.dtree' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.localstore' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.propertytester' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.projectvariables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.resources.refresh.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.watson' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.filtermatchers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.refresh' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.team' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.resources.variableresolvers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='[3.1.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources' version='3.7.101.v20120125-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources; singleton:=true&#xA;Bundle-Version: 3.7.101.v20120125-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'>
      <update id='org.eclipse.core.resources.win32.x86' range='[0.0.0,3.5.100.v20110423-0524)' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='%win32FragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.core.resources' version='3.5.100.v20110423-0524'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.resources.win32.x86' version='3.5.100.v20110423-0524'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.resources.win32.x86;singleton:=true&#xA;Bundle-Version: 3.5.100.v20110423-0524&#xA;Fragment-Host: org.eclipse.core.resources;bundle-version=&quot;[3.5.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime' version='3.7.0.v20110110'>
      <update id='org.eclipse.core.runtime' range='[0.0.0,3.7.0.v20110110)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.legacy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.contenttype' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.auth' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime.auth' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime' version='3.7.0.v20110110'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110110
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'>
      <update id='org.eclipse.core.runtime.compatibility' range='[0.0.0,3.2.100.v20100505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Runtime Plug-in Compatibility'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
        <provided namespace='java.package' name='org.eclipse.core.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.plugins' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.model' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.1.100,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime.compatibility' version='3.2.100.v20100505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime.compatibility; singleton:=true&#xA;Bundle-Version: 3.2.100.v20100505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime.compatibility.auth' version='3.2.200.v20110110' singleton='false'>
      <update id='org.eclipse.core.runtime.compatibility.auth' range='[0.0.0,3.2.200.v20110110)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Authorization Compatibility Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.auth' version='3.2.200.v20110110'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.auth' version='3.2.200.v20110110'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime.auth' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime.compatibility.auth' version='3.2.200.v20110110'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime.compatibility.auth&#xA;Bundle-Version: 3.2.200.v20110110
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505' singleton='false'>
      <update id='org.eclipse.core.runtime.compatibility.registry' range='[0.0.0,3.5.0.v20110505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Eclipse Registry Compatibility Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.registry' version='3.5.0.v20110505'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.5.0,3.6.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.runtime.compatibility.registry' version='3.5.0.v20110505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.runtime.compatibility.registry&#xA;Bundle-Version: 3.5.0.v20110505&#xA;Fragment-Host: org.eclipse.equinox.registry;bundle-version=&quot;[3.5.0,3.6.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.core.variables' version='3.2.500.v20110928-1503'>
      <update id='org.eclipse.core.variables' range='[0.0.0,3.2.500.v20110928-1503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Core Variables'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.variables' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.core.variables' version='3.2.500.v20110928-1503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.core.variables; singleton:=true&#xA;Bundle-Version: 3.2.500.v20110928-1503
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.debug.core' version='3.7.1.v20111129-2031'>
      <update id='org.eclipse.debug.core' range='[0.0.0,3.7.1.v20111129-2031)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Debug Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
        <provided namespace='osgi.bundle' name='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
        <provided namespace='java.package' name='org.eclipse.debug.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.sourcelookup.containers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.core.variables' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.debug.core' version='3.7.1.v20111129-2031'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.debug.core; singleton:=true&#xA;Bundle-Version: 3.7.1.v20111129-2031
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'>
      <update id='org.eclipse.debug.ui' range='[0.0.0,3.7.102.v20111129-1423_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Debug UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='49'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.breakpointGroups' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.actions.variables.details' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.breakpoints.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.commands.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.contextlaunching' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.elements.adapters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.importexport.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.importexport.launchconfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.launchConfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.memory.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.model.elements' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.sourcelookup.browsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.stringsubstitution' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.breadcrumb' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.model.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.viewers.update' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.breakpoints' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.launch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.memory.renderings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.modules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.registers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.variables' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.internal.ui.views.variables.details' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.memory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.debug.ui.sourcelookup' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.console' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ui.forms.widgets' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.debug.ui' version='3.7.102.v20111129-1423_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.debug.ui; singleton:=true&#xA;Bundle-Version: 3.7.102.v20111129-1423_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf' version='3.1.300.v20110531-2218'>
      <update id='org.eclipse.ecf' range='[0.0.0,3.1.300.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Core API'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' version='3.1.300.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf' version='3.1.300.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core' version='3.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.jobs' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.start' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.status' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.user' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.identity' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.concurrent.future' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf' version='3.1.300.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Import-Package: org.eclipse.core.runtime.jobs,org.eclipse.equinox.concurrent.future;version=&quot;1.0.0&quot;;resolution:=optional,org.osgi.framework;version=&quot;1.3.0&quot;,org.osgi.service.log;version=&quot;1.3.0&quot;,org.osgi.util.tracker;version=&quot;1.3.2&quot;&#xA;Bundle-ManifestVersion: 2&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Manifest-Version: 1.0&#xA;Bundle-Name: %plugin.name&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-ActivationPolicy: lazy&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-Version: 3.1.300.v20110531-2218&#xA;Export-Package: org.eclipse.ecf.core;version=&quot;3.0.0&quot;,org.eclipse.ecf.core.events,org.eclipse.ecf.core.jobs;version=&quot;1.0&quot;;x-internal:=true,org.eclipse.ecf.core.provider,org.eclipse.ecf.core.security,org.eclipse.ecf.core.start,org.eclipse.ecf.core.status;version=&quot;1.0&quot;;x-internal:=true,org.eclipse.ecf.core.user,org.eclipse.ecf.core.util,org.eclipse.ecf.internal.core;x-internal:=true&#xA;Require-Bundle: org.eclipse.equinox.common,org.eclipse.equinox.registry,org.eclipse.ecf.identity;visibility:=reexport&#xA;Bundle-Activator: org.eclipse.ecf.internal.core.ECFPlugin&#xA;Bundle-SymbolicName: org.eclipse.ecf;singleton:=true&#xA;Eclipse-LazyStart: true&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.filetransfer' version='5.0.0.v20110531-2218'>
      <update id='org.eclipse.ecf.filetransfer' range='[0.0.0,5.0.0.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Filetransfer API'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' version='5.0.0.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' version='5.0.0.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socket' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.events.socketfactory' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.filetransfer.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.filetransfer' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.filetransfer' version='5.0.0.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Import-Package: org.eclipse.core.runtime.jobs,org.osgi.framework;version=&quot;1.3.0&quot;,org.osgi.service.log;version=&quot;1.3.0&quot;,org.osgi.service.url;version=&quot;1.0.0&quot;,org.osgi.util.tracker;version=&quot;1.3.2&quot;&#xA;Bundle-ManifestVersion: 2&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Manifest-Version: 1.0&#xA;Bundle-Name: %plugin.name&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-ActivationPolicy: lazy&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-Version: 5.0.0.v20110531-2218&#xA;Export-Package: org.eclipse.ecf.filetransfer,org.eclipse.ecf.filetransfer.events,org.eclipse.ecf.filetransfer.events.socket;version:=&quot;1.0&quot;;x-internal:=&quot;true&quot;,org.eclipse.ecf.filetransfer.events.socketfactory,org.eclipse.ecf.filetransfer.identity,org.eclipse.ecf.filetransfer.service,org.eclipse.ecf.internal.filetransfer;x-internal:=true&#xA;Require-Bundle: org.eclipse.equinox.common,org.eclipse.equinox.registry,org.eclipse.ecf&#xA;Bundle-Activator: org.eclipse.ecf.internal.filetransfer.Activator&#xA;Bundle-SymbolicName: org.eclipse.ecf.filetransfer;singleton:=true&#xA;Eclipse-LazyStart: true&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.identity' version='3.1.100.v20110531-2218'>
      <update id='org.eclipse.ecf.identity' range='[0.0.0,3.1.100.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Core Identity API'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' version='3.1.100.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.identity' version='3.1.100.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.identity' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.core.util' version='3.2.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.core.identity' version='3.2.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.identity' version='3.1.100.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Import-Package: org.eclipse.osgi.service.debug;version=&quot;1.0.0&quot;,org.osgi.framework;version=&quot;1.3.0&quot;,org.osgi.service.log;version=&quot;1.3.0&quot;,org.osgi.util.tracker;version=&quot;1.3.2&quot;&#xA;Bundle-ManifestVersion: 2&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Manifest-Version: 1.0&#xA;Bundle-Name: %plugin.name&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-ActivationPolicy: lazy; exclude:=&quot;org.eclipse.ecf.core.util&quot;&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-Version: 3.1.100.v20110531-2218&#xA;Export-Package: org.eclipse.ecf.core.identity;version=&quot;3.2.0&quot;,org.eclipse.ecf.core.util;version=&quot;3.2.0&quot;,org.eclipse.ecf.internal.core.identity;version=&quot;3.2.0&quot;;x-internal:=true&#xA;Require-Bundle: org.eclipse.equinox.common,org.eclipse.equinox.registry&#xA;Bundle-Activator: org.eclipse.ecf.internal.core.identity.Activator&#xA;Bundle-SymbolicName: org.eclipse.ecf.identity;singleton:=true&#xA;Eclipse-LazyStart: true&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer' version='3.2.0.v20110531-2218'>
      <update id='org.eclipse.ecf.provider.filetransfer' range='[0.0.0,3.2.0.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Filetransfer Provider'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='12'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' version='3.2.0.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' version='3.2.0.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.browse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.identity' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.outgoing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.retrieve' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.net.proxy' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.events.socket' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer' version='3.2.0.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-Version: 3.2.0.v20110531-2218&#xA;Bundle-ActivationPolicy: lazy&#xA;Eclipse-LazyStart: true&#xA;Export-Package: org.eclipse.ecf.internal.provider.filetransfer;x-internal:=true,org.eclipse.ecf.provider.filetransfer;x-friends:=&quot;org.eclipse.equinox.p2.repository&quot;,org.eclipse.ecf.provider.filetransfer.browse,org.eclipse.ecf.provider.filetransfer.events.socket;version=&quot;1.0&quot;;x-friends:=&quot;org.eclipse.ecf.provider.filetransfer.httpclient&quot;,org.eclipse.ecf.provider.filetransfer.identity,org.eclipse.ecf.provider.filetransfer.outgoing,org.eclipse.ecf.provider.filetransfer.retrieve,org.eclipse.ecf.provider.filetransfer.util&#xA;Import-Package: org.eclipse.core.net.proxy;resolution:=optional,org.eclipse.core.runtime.jobs,org.eclipse.ecf.provider.filetransfer.events.socket;version=&quot;[1.0.0,2.0.0)&quot;,org.eclipse.osgi.util;version=&quot;1.0.0&quot;,org.osgi.framework;version=&quot;1.3.0&quot;,org.osgi.service.log;version=&quot;1.3.0&quot;,org.osgi.service.url;version=&quot;1.0.0&quot;,org.osgi.util.tracker;version=&quot;1.3.2&quot;&#xA;Manifest-Version: 1.0&#xA;Bundle-Activator: org.eclipse.ecf.internal.provider.filetransfer.Activator&#xA;Bundle-ClassPath: .&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin&#xA;Require-Bundle: org.eclipse.equinox.common,org.eclipse.ecf,org.eclipse.ecf.filetransfer,org.eclipse.equinox.registry&#xA;Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer;singleton:=true&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-Name: %plugin.name&#xA;Bundle-ManifestVersion: 2
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.0.v20110531-2218'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient' range='[0.0.0,4.0.0.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF HttpClient Filetransfer Provider'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.0.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.0.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.provider.filetransfer.httpclient' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.commons.httpclient' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.auth' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.methods' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.params' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.protocol' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.apache.commons.httpclient.util' range='[3.0.1,3.1.0]'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.2'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient' version='4.0.0.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Import-Package: org.apache.commons.httpclient;version=&quot;[3.0.1,3.1.0]&quot;,org.apache.commons.httpclient.auth;version=&quot;[3.0.1,3.1.0]&quot;,org.apache.commons.httpclient.methods;version=&quot;[3.0.1,3.1.0]&quot;,org.apache.commons.httpclient.params;version=&quot;[3.0.1,3.1.0]&quot;,org.apache.commons.httpclient.protocol;version=&quot;[3.0.1,3.1.0]&quot;,org.apache.commons.httpclient.util;version=&quot;[3.0.1,3.1.0]&quot;,org.eclipse.core.runtime.jobs,org.eclipse.osgi.util;version=&quot;1.0.0&quot;,org.osgi.framework;version=&quot;1.3.0&quot;,org.osgi.service.log;version=&quot;1.3.0&quot;,org.osgi.service.url;version=&quot;1.0.0&quot;,org.osgi.util.tracker;version=&quot;1.3.2&quot;&#xA;Bundle-ManifestVersion: 2&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Manifest-Version: 1.0&#xA;Bundle-Name: %plugin.name&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-ActivationPolicy: lazy&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-Version: 4.0.0.v20110531-2218&#xA;Export-Package: org.eclipse.ecf.internal.provider.filetransfer.httpclient;x-internal:=true,org.eclipse.ecf.provider.filetransfer.httpclient&#xA;Require-Bundle: org.eclipse.equinox.common,org.eclipse.ecf.provider.filetransfer,org.eclipse.ecf,org.eclipse.ecf.filetransfer&#xA;Bundle-Activator: org.eclipse.ecf.internal.provider.filetransfer.httpclient.Activator&#xA;Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient;singleton:=true&#xA;Eclipse-LazyStart: true&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' version='1.0.0.v20110531-2218' singleton='false'>
      <update id='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' range='[0.0.0,1.0.0.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Filetransfer Httpclient SSL Fragment'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' version='1.0.0.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' version='1.0.0.v20110531-2218'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf.provider.filetransfer.httpclient' version='1.0.0.v20110531-2218'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.httpclient' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' version='1.0.0.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-Vendor: %plugin.provider&#xA;Bundle-ManifestVersion: 2&#xA;Bundle-RequiredExecutionEnvironment: CDC-1.1/Foundation-1.1,J2SE-1.4&#xA;Bundle-Localization: plugin&#xA;Bundle-Name: %plugin.name&#xA;Manifest-Version: 1.0&#xA;Fragment-Host: org.eclipse.ecf.provider.filetransfer.httpclient&#xA;Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.httpclient.ssl&#xA;Bundle-Version: 1.0.0.v20110531-2218&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Ant-Version: Apache Ant 1.7.1
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20110531-2218' singleton='false'>
      <update id='org.eclipse.ecf.provider.filetransfer.ssl' range='[0.0.0,1.0.0.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF Filetransfer SSL Fragment'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20110531-2218'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf.provider.filetransfer' version='1.0.0.v20110531-2218'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='2.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.provider.filetransfer.ssl' version='1.0.0.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-ManifestVersion: 2&#xA;Bundle-RequiredExecutionEnvironment: J2SE-1.4&#xA;Bundle-Localization: plugin&#xA;Bundle-Name: %plugin.name&#xA;Bundle-Version: 1.0.0.v20110531-2218&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-SymbolicName: org.eclipse.ecf.provider.filetransfer.ssl&#xA;Import-Package: javax.net.ssl&#xA;Fragment-Host: org.eclipse.ecf.provider.filetransfer;bundle-version=&quot;2.0.0&quot;&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Manifest-Version: 1.0
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ecf.ssl' version='1.0.100.v20110531-2218' singleton='false'>
      <update id='org.eclipse.ecf.ssl' range='[0.0.0,1.0.100.v20110531-2218)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin.name' value='ECF SSL Fragment'/>
        <property name='df_LT.plugin.provider' value='Eclipse.org - ECF'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%plugin.provider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' version='1.0.100.v20110531-2218'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ecf.ssl' version='1.0.100.v20110531-2218'/>
        <provided namespace='java.package' name='org.eclipse.ecf.internal.ssl' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ecf' version='1.0.100.v20110531-2218'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='0.0.0'/>
        <required namespace='java.package' name='javax.net' range='0.0.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ecf.ssl' version='1.0.100.v20110531-2218'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-RequiredExecutionEnvironment: J2SE-1.4&#xA;Ant-Version: Apache Ant 1.7.1&#xA;Bundle-Name: %plugin.name&#xA;Created-By: 1.5.0_22-b03 (Sun Microsystems Inc.)&#xA;Manifest-Version: 1.0&#xA;Bundle-Vendor: %plugin.provider&#xA;Bundle-SymbolicName: org.eclipse.ecf.ssl&#xA;Import-Package: javax.net,javax.net.ssl,org.eclipse.osgi.service.security&#xA;Bundle-ManifestVersion: 2&#xA;Bundle-Version: 1.0.100.v20110531-2218&#xA;Bundle-Localization: plugin&#xA;Fragment-Host: org.eclipse.ecf&#xA;Export-Package: org.eclipse.ecf.internal.ssl;x-internal:=true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.app' version='1.3.100.v20110321'>
      <update id='org.eclipse.equinox.app' range='[0.0.0,1.3.100.v20110321)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Application Container'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
        <provided namespace='java.package' name='org.eclipse.equinox.app' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.app' version='0.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.application' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.runnable' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.condpermadmin' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.service.event' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.app' version='1.3.100.v20110321'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.app; singleton:=true&#xA;Bundle-Version: 1.3.100.v20110321
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.common' version='3.6.0.v20110523'>
      <update id='org.eclipse.equinox.common' range='[0.0.0,3.6.0.v20110523)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Common Eclipse Runtime'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.boot' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.runtime' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.events' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='java.package' name='org.eclipse.equinox.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.urlconversion' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.url' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.common' version='3.6.0.v20110523'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.common; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110523
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.concurrent' version='1.0.200.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.concurrent' range='[0.0.0,1.0.200.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.pluginProvider' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Concurrent API'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%pluginProvider'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.concurrent' version='1.0.200.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.concurrent' version='1.0.200.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.concurrent.future' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='3.4.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.concurrent' version='1.0.200.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.concurrent&#xA;Bundle-Version: 1.0.200.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.ds' version='1.3.1.R37x_v20110701'>
      <update id='org.eclipse.equinox.ds' range='[0.0.0,1.3.1.R37x_v20110701)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Declarative Services'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='This bundle provides support for OSGi Declarative Services'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' version='1.3.1.R37x_v20110701'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.ds' version='1.3.1.R37x_v20110701'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.ds' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.ds.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.ds.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.ds.storage.file' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.xml' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.xml.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.string' version='0.0.0'/>
        <provided namespace='java.package' name='org.apache.felix.scr' version='1.6.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.event' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.hash' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.pool' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.ref' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.threadpool' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.util.timer' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <required namespace='java.package' name='org.apache.felix.scr' range='[1.6.0,1.7.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.ds' version='1.3.1.R37x_v20110701'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='3'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.ds;singleton:=true&#xA;Bundle-Version: 1.3.1.R37x_v20110701
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:equinox.use.ds, propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:equinox.use.ds, propValue:true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.event' version='1.2.100.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.event' range='[0.0.0,1.2.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Event Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' version='1.2.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.event' version='1.2.100.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.event.mapper' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.event' version='1.2.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.event&#xA;Bundle-Version: 1.2.100.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin' version='2.0.0.v20110815-1438'>
      <update id='org.eclipse.equinox.frameworkadmin' range='[0.0.0,2.0.0.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Framework Admin'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' version='2.0.0.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin' version='2.0.0.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.frameworkadmin' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.4.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin' version='2.0.0.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin;singleton:=true&#xA;Bundle-Version: 2.0.0.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.300.v20110815-1438'>
      <update id='org.eclipse.equinox.frameworkadmin.equinox' range='[0.0.0,1.0.300.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Framework Admin for Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.300.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.300.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox.utils' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.internal.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.frameworkadmin.equinox' version='1.0.300.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.frameworkadmin.equinox;singleton:=true&#xA;Bundle-Version: 1.0.300.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.http.jetty' range='[0.0.0,2.0.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jetty Http Service'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.jetty' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='java.package' name='javax.servlet' range='[2.5.0,2.6.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.5.0,2.6.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.http.servlet' range='1.0.0'/>
        <required namespace='java.package' name='org.mortbay.component' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.bio' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.handler' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.nio' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.security' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.jetty.servlet' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.mortbay.log' range='[6.1.0,7.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.jetty' version='2.0.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.jetty&#xA;Bundle-Version: 2.0.100.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'>
      <update id='org.eclipse.equinox.http.registry' range='[0.0.0,1.1.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Http Service Registry Extensions'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.registry' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.3.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.registry' version='1.1.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.registry;singleton:=true&#xA;Bundle-Version: 1.1.100.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.http.servlet' range='[0.0.0,1.1.200.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Http Services Servlet'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.http.servlet' version='1.1.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='javax.servlet' range='2.3.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.3.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.0,1.3.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.http.servlet' version='1.1.200.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.http.servlet&#xA;Bundle-Version: 1.1.200.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.jsp.jasper' range='[0.0.0,1.0.300.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jasper Jsp Support Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.jsp.jasper' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='java.package' name='javax.servlet' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='[2.4.0,3.0.0)'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='[2.0.0,2.1.0)'/>
        <required namespace='java.package' name='org.apache.jasper.servlet' range='[0.0.0,6.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.1'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.jsp.jasper' version='1.0.300.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.jsp.jasper&#xA;Bundle-Version: 1.0.300.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503' singleton='false'>
      <update id='org.eclipse.equinox.jsp.jasper.registry' range='[0.0.0,1.0.200.v20100503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Jasper Jsp Registry Support Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
        <provided namespace='java.package' name='org.eclipse.equinox.jsp.jasper.registry' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.jsp.jasper' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.jsp.jasper.registry' version='1.0.200.v20100503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.jsp.jasper.registry&#xA;Bundle-Version: 1.0.200.v20100503
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher' version='1.2.0.v20110502'>
      <update id='org.eclipse.equinox.launcher' range='[0.0.0,1.2.0.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.core.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.launcher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.launcher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher;singleton:=true&#xA;Bundle-Version: 1.2.0.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'>
      <update id='org.eclipse.equinox.launcher.win32.win32.x86' range='[0.0.0,1.1.100.v20110502)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Launcher Win32 X86 Fragment'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='launcher.win32.win32.x86'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.launcher' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.0.0,1.3.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.launcher.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 1.1.100.v20110502&#xA;Fragment-Host: org.eclipse.equinox.launcher;bundle-version=&quot;[1.0.0,1.3.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.artifact.repository' version='1.1.101.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.artifact.repository' range='[0.0.0,1.1.101.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Artifact Repository Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' version='1.1.101.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' version='1.1.101.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.md5' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.processors.pack200' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.artifact.repository.processing' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='26'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.3.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.artifact.repository' version='1.1.101.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.artifact.repository;singleton:=true&#xA;Bundle-Version: 1.1.101.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.console' version='1.0.300.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.console' range='[0.0.0,1.0.300.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Console'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' version='1.0.300.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.console' version='1.0.300.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.console' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.console' version='1.0.300.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.console;singleton:=true&#xA;Bundle-Version: 1.0.300.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'>
      <update id='org.eclipse.equinox.p2.core' range='[0.0.0,2.1.1.v20120113-1346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.core.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.5.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.core' version='2.1.1.v20120113-1346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.core;singleton:=true&#xA;Bundle-Version: 2.1.1.v20120113-1346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.core.feature.feature.group' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129' singleton='false'>
      <update id='org.eclipse.equinox.p2.core.feature.feature.group' range='[0.0.0,1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Equinox p2 Core Function'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides a minimal headless provisioning system.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='37'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.artifact.repository' range='[1.1.101.v20110815-1419,1.1.101.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.console' range='[1.0.300.v20110815-1419,1.0.300.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core' range='[2.1.1.v20120113-1346,2.1.1.v20120113-1346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' range='[2.1.1.v20111126-0211,2.1.1.v20111126-0211]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' range='[2.1.1.R37x_v20111003,2.1.1.R37x_v20111003]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' range='[1.0.200.v20110815-1419,1.0.200.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' range='[2.1.0.v20110815-1419,2.1.0.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' range='[1.2.0.v20110815-1419,1.2.0.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' range='[2.1.1.v20120113-1346,2.1.1.v20120113-1346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='[2.1.1.v20110815-1419,2.1.1.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' range='[1.0.300.v20110815-1419,1.0.300.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0.v20110815-1438,2.0.0.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' range='[2.3.0.v20110329,2.3.0.v20110329]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' range='[2.3.0.v20110329,2.3.0.v20110329]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf' range='[3.1.300.v20110531-2218,3.1.300.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.filetransfer' range='[5.0.0.v20110531-2218,5.0.0.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.identity' range='[3.1.100.v20110531-2218,3.1.100.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer' range='[3.2.0.v20110531-2218,3.2.0.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient' range='[4.0.0.v20110531-2218,4.0.0.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.httpclient.ssl' range='[1.0.0.v20110531-2218,1.0.0.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.provider.filetransfer.ssl' range='[1.0.0.v20110531-2218,1.0.0.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ecf.ssl' range='[1.0.100.v20110531-2218,1.0.100.v20110531-2218]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.codec' range='[1.3.0.v201101211617,1.3.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.httpclient' range='[3.1.0.v201012070820,3.1.0.v201012070820]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.0.4.v201101211617,1.0.4.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0.v20110815-1438,2.0.0.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.frameworkadmin.equinox' range='[1.0.300.v20110815-1438,1.0.300.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.4.2.v20120111-2020,3.4.2.v20120111-2020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.1.1.R37x_v20110822-1018,1.1.1.R37x_v20110822-1018]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' range='[1.0.200.v20110815-1438,1.0.200.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ql' range='[2.0.100.v20110815-1419,2.0.100.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' range='[1.0.0.v20111128-0624,1.0.0.v20111128-0624]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' range='[2.1.1.R37x_v20111111,2.1.1.R37x_v20111111]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.100.100.v20100503,1.100.100.v20100503]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' range='[1.0.200.v20100503,1.0.200.v20100503]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86_64' range='[1.0.0.v20110502,1.0.0.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.jar' range='[1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129,1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.core.feature.feature.jar' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.featureName' value='Equinox p2 Core Function'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides a minimal headless provisioning system.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.jar' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.p2.core.feature' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.p2.core.feature' version='1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.director' version='2.1.1.v20111126-0211'>
      <update id='org.eclipse.equinox.p2.director' range='[0.0.0,2.1.1.v20111126-0211)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director' version='2.1.1.v20111126-0211'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director' version='2.1.1.v20111126-0211'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.rollback' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.planner' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='[2.2.0,2.4.0)'/>
        <required namespace='osgi.bundle' name='org.sat4j.pb' range='[2.2.0,2.4.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director' version='2.1.1.v20111126-0211'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director;singleton:=true&#xA;Bundle-Version: 2.1.1.v20111126-0211
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.director.app' version='1.0.300.v20111126-0153'>
      <update id='org.eclipse.equinox.p2.director.app' range='[0.0.0,1.0.300.v20111126-0153)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Director Application'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' version='1.0.300.v20111126-0153'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.director.app' version='1.0.300.v20111126-0153'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.director.app' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='20'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.director.app' version='1.0.300.v20111126-0153'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.director.app;singleton:=true&#xA;Bundle-Version: 1.0.300.v20111126-0153
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.directorywatcher' version='1.0.300.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.directorywatcher' range='[0.0.0,1.0.300.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Directory Watcher'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' version='1.0.300.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.directorywatcher' version='1.0.300.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.directorywatcher' version='1.0.300.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.directorywatcher;singleton:=true&#xA;Bundle-Version: 1.0.300.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'>
      <update id='org.eclipse.equinox.p2.engine' range='[0.0.0,2.1.1.R37x_v20111003)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Engine'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.query' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='34'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.signedcontent' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.engine' version='2.1.1.R37x_v20111003'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.engine;singleton:=true&#xA;Bundle-Version: 2.1.1.R37x_v20111003
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.extensionlocation' version='1.2.100.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.extensionlocation' range='[0.0.0,1.2.100.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Extension Location Repository Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' version='1.2.100.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.extensionlocation' version='1.2.100.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.extensionlocation' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='23'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.extensionlocation' version='1.2.100.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.extensionlocation;singleton:=true&#xA;Bundle-Version: 1.2.100.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.extras.feature.feature.group' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO' singleton='false'>
      <update id='org.eclipse.equinox.p2.extras.feature.feature.group' range='[0.0.0,1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Add-on Function for p2'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides some backward compatibility support (e.g. drop-ins, legacy update site) and the metadata generation facility.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extras.feature.feature.group' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='9'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' range='[1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129,1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.director.app' range='[1.0.300.v20111126-0153,1.0.300.v20111126-0153]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.directorywatcher' range='[1.0.300.v20110815-1419,1.0.300.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' range='[1.1.100.v20110815-1419,1.1.100.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' range='[1.2.0.v20110815-1419,1.2.0.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extensionlocation' range='[1.2.100.v20110815-1419,1.2.100.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.tools' range='[2.0.100.v20110815-1438,2.0.100.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' range='[1.0.0.v20110815-1438,1.0.0.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extras.feature.feature.jar' range='[1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO,1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.extras.feature.feature.jar' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.featureName' value='Add-on Function for p2'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides some backward compatibility support (e.g. drop-ins, legacy update site) and the metadata generation facility.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2010 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extras.feature.feature.jar' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.p2.extras.feature' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.p2.extras.feature' version='1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.garbagecollector' version='1.0.200.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.garbagecollector' range='[0.0.0,1.0.200.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Garbage Collector'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.garbagecollector' version='1.0.200.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.garbagecollector' version='1.0.200.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.garbagecollector' version='1.0.200.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.garbagecollector;singleton:=true&#xA;Bundle-Version: 1.0.200.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.jarprocessor' version='1.0.200.v20110815-1438'>
      <update id='org.eclipse.equinox.p2.jarprocessor' range='[0.0.0,1.0.200.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning JAR Processor'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.jarprocessor' version='1.0.200.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.jarprocessor' version='1.0.200.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.unsigner' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.jarprocessor.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.internal.provisional.equinox.p2.jarprocessor' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.jarprocessor' version='1.0.200.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.jarprocessor;singleton:=true&#xA;Bundle-Version: 1.0.200.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.metadata' range='[0.0.0,2.1.0.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata' version='2.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.query' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata' version='2.1.0.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata;singleton:=true&#xA;Bundle-Version: 2.1.0.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.metadata.repository' range='[0.0.0,1.2.0.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Metadata Repository'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.metadata.io' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.metadata.repository' version='1.2.0.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.metadata.repository;singleton:=true&#xA;Bundle-Version: 1.2.0.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.operations' version='2.1.1.R37x_v20111111'>
      <update id='org.eclipse.equinox.p2.operations' range='[0.0.0,2.1.1.R37x_v20111111)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Operations API'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.operations' version='2.1.1.R37x_v20111111'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.operations' version='2.1.1.R37x_v20111111'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.operations' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.operations' version='2.1.1.R37x_v20111111'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.operations;singleton:=true&#xA;Bundle-Version: 2.1.1.R37x_v20111111
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher' version='1.2.0.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.publisher' range='[0.0.0,1.2.0.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher Infrastructure'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher' version='1.2.0.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher' version='1.2.0.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='22'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.expression' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.index' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.index' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher' version='1.2.0.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher;singleton:=true&#xA;Bundle-Version: 1.2.0.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.publisher.eclipse' version='1.0.0.v20110815-1438'>
      <update id='org.eclipse.equinox.p2.publisher.eclipse' range='[0.0.0,1.0.0.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning Publisher for Eclipse'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.0.0.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.publisher.eclipse' version='1.0.0.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.compatibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.build.publisher' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.publishing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.pde.internal.swt.tools' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='32'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.3.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.5.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.application' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.publisher.eclipse' version='1.0.0.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.publisher.eclipse;singleton:=true&#xA;Bundle-Version: 1.0.0.v20110815-1438
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.ql' version='2.0.100.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.ql' range='[0.0.0,2.0.100.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning p2 query language'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ql' version='2.0.100.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.ql' version='2.0.100.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.ql' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.5.1'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.ql' version='2.0.100.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.ql;singleton:=true&#xA;Bundle-Version: 2.0.100.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.rcp.feature.feature.group' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO' singleton='false'>
      <update id='org.eclipse.equinox.p2.rcp.feature.feature.group' range='[0.0.0,1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Equinox p2 RCP Management Facilities'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides SWT based UI component for p2.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2011 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.rcp.feature.feature.group' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' range='[1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129,1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui' range='[2.1.1.v20120113-1346,2.1.1.v20120113-1346]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk.scheduler' range='[1.0.100.v20110815-1419,1.0.100.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' range='[1.1.200.v20110815-1419,1.1.200.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.1.0.v20101004,1.1.0.v20101004]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk' range='[1.0.200.v20110815-1419,1.0.200.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.rcp.feature.feature.jar' range='[1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO,1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.rcp.feature.feature.jar' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.featureName' value='Equinox p2 RCP Management Facilities'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Provides SWT based UI component for p2.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2011 EclipseSource Inc. and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;EclipseSource - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.rcp.feature.feature.jar' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.p2.rcp.feature' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.p2.rcp.feature' version='1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright uri='%25copyrightURL' url='%25copyrightURL'>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.reconciler.dropins' version='1.1.100.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.reconciler.dropins' range='[0.0.0,1.1.100.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Drop-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.reconciler.dropins' version='1.1.100.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' version='1.1.100.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.reconciler.dropins' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='27'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.extensionlocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.update' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.directorywatcher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.reconciler.dropins' version='1.1.100.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.reconciler.dropins;singleton:=true&#xA;Bundle-Version: 1.1.100.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'>
      <update id='org.eclipse.equinox.p2.repository' range='[0.0.0,2.1.1.v20120113-1346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Repository'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='24'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='3.3.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='3.2.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.security.storage' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository' version='2.1.1.v20120113-1346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository;singleton:=true&#xA;Bundle-Version: 2.1.1.v20120113-1346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.repository.tools' version='2.0.100.v20110815-1438'>
      <update id='org.eclipse.equinox.p2.repository.tools' range='[0.0.0,2.0.100.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning Repository Tools'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.repository.tools' version='2.0.100.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository.tools' version='2.0.100.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.comparator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.mirroring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.tools' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.internal.repository.tools.analyzer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.tools.analyzer' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.repository.tools.comparator' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='30'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.3.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.4.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.repository.tools' version='2.0.100.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.repository.tools;singleton:=true&#xA;Bundle-Version: 2.0.100.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.1.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.touchpoint.eclipse' range='[0.0.0,2.1.1.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Eclipse Touchpoint'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.1.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.1.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.eclipse.actions' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.update' version='2.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.touchpoint.eclipse.query' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='33'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.garbagecollector' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='1.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='1.1.1'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.4.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.eclipse' version='2.1.1.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.eclipse;singleton:=true&#xA;Bundle-Version: 2.1.1.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.touchpoint.natives' version='1.0.300.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.touchpoint.natives' range='[0.0.0,1.0.300.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Native Touchpoint'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.0.300.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.touchpoint.natives' version='1.0.300.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.touchpoint.natives.actions' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.touchpoint.natives' version='1.0.300.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.touchpoint.natives;singleton:=true&#xA;Bundle-Version: 1.0.300.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.transport.ecf' version='1.0.0.v20111128-0624' singleton='false'>
      <update id='org.eclipse.equinox.p2.transport.ecf' range='[0.0.0,1.0.0.v20111128-0624)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning ECF based Transport'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.transport.ecf' version='1.0.0.v20111128-0624'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.transport.ecf' version='1.0.0.v20111128-0624'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.transport.ecf' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ecf' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.filetransfer' range='4.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ecf.provider.filetransfer' range='3.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.core' range='2.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.repository' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='3.7.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.jobs' range='3.5.100'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.transport.ecf' version='1.0.0.v20111128-0624'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.transport.ecf&#xA;Bundle-Version: 1.0.0.v20111128-0624
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.ui' version='2.1.1.v20120113-1346'>
      <update id='org.eclipse.equinox.p2.ui' range='[0.0.0,2.1.1.v20120113-1346)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning UI Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui' version='2.1.1.v20120113-1346'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui' version='2.1.1.v20120113-1346'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.query' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.p2.ui' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='32'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security.ui' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.operations' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.ui' version='2.1.1.v20120113-1346'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.ui;singleton:=true&#xA;Bundle-Version: 2.1.1.v20120113-1346
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.ui.importexport' version='1.0.1.R37x_v20111103'>
      <update id='org.eclipse.equinox.p2.ui.importexport' range='[0.0.0,1.0.1.R37x_v20111103)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Import and Export'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.importexport' version='1.0.1.R37x_v20111103'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui.importexport' version='1.0.1.R37x_v20111103'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.importexport' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.importexport.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.extensionlocation' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='2.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.repository.io' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.persistence' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.dialogs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.model' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.viewers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.director' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.operations' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='2.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='2.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.ui.importexport' version='1.0.1.R37x_v20111103'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.ui.importexport;singleton:=true&#xA;Bundle-Version: 1.0.1.R37x_v20111103
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.ui.sdk' version='1.0.200.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.ui.sdk' range='[0.0.0,1.0.200.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning Platform Update Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk' version='1.0.200.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui.sdk' version='1.0.200.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.sdk' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.sdk.prefs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='15'>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.operations' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='3.6.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.ui.sdk' version='1.0.200.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.ui.sdk;singleton:=true&#xA;Bundle-Version: 1.0.200.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.ui.sdk.scheduler' version='1.0.100.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.ui.sdk.scheduler' range='[0.0.0,1.0.100.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Provisioning Platform Automatic Update Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.sdk.scheduler' version='1.0.100.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui.sdk.scheduler' version='1.0.100.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.sdk.scheduler' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='25'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatechecker' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.ui' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='4.0.1'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.engine.phases' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.metadata.query' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.ui.query' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.core.eventbus' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.updatechecker' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.operations' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.ui' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.6.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.ui.sdk.scheduler' version='1.0.100.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.ui.sdk.scheduler;singleton:=true&#xA;Bundle-Version: 1.0.100.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.updatechecker' version='1.1.200.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.updatechecker' range='[0.0.0,1.1.200.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Update Checker'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatechecker' version='1.1.200.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatechecker' version='1.1.200.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatechecker' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.p2.updatechecker' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.planner' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.updatechecker' version='1.1.200.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.updatechecker;singleton:=true&#xA;Bundle-Version: 1.1.200.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.updatesite' version='1.0.300.v20110815-1419'>
      <update id='org.eclipse.equinox.p2.updatesite' range='[0.0.0,1.0.300.v20110815-1419)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Provisioning Legacy Update Site Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' version='1.0.300.v20110815-1419'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.p2.updatesite' version='1.0.300.v20110815-1419'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.artifact' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.p2.updatesite.metadata' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='29'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata.repository' range='0.1.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.artifact.repository' range='0.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.app' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.artifact.repository.simple' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.core.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.p2.repository' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.core' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.metadata.expression' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.actions' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.publisher.eclipse' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.query' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.artifact.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.metadata.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.p2.repository.spi' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.spi.p2.publisher' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='1.1.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.p2.updatesite' version='1.0.300.v20110815-1419'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.p2.updatesite;singleton:=true&#xA;Bundle-Version: 1.0.300.v20110815-1419
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.p2.user.ui.feature.group' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl' singleton='false'>
      <update id='org.eclipse.equinox.p2.user.ui.feature.group' range='[0.0.0,2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Equinox p2 Provisioning for IDEs.'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Eclipse p2 Provisioning Platform for use in IDE related scenarios'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2010 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.core.feature.feature.group' range='[1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129,1.0.1.v20110906-1605-8290FZ9FVKHVRKtmx3fpNuo02129]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.extras.feature.feature.group' range='[1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO,1.0.1.v20110906-1605-7A4FD4DiVOMap8cHSc6vPuny4gqO]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.rcp.feature.feature.group' range='[1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO,1.0.1.v20110906-1605-782EqBqNKGVkiV-PUsgz-uny4gqO]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.updatesite' range='[1.0.300.v20110815-1419,1.0.300.v20110815-1419]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.ui.importexport' range='[1.0.1.R37x_v20111103,1.0.1.R37x_v20111103]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.jar' range='[2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl,2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.p2.user.ui.feature.jar' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.featureName' value='Equinox p2 Provisioning for IDEs.'/>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.description' value='Eclipse p2 Provisioning Platform for use in IDE related scenarios'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2010 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.jar' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.equinox.p2.user.ui' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.equinox.p2.user.ui' version='2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'>
      <update id='org.eclipse.equinox.preferences' range='[0.0.0,3.4.2.v20120111-2020)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Eclipse Preferences Mechanism'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.preferences.exchange' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.preferences' version='3.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.prefs' version='1.1.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.registry' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.1,1.2.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.preferences' version='3.4.2.v20120111-2020'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.preferences; singleton:=true&#xA;Bundle-Version: 3.4.2.v20120111-2020
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'>
      <update id='org.eclipse.equinox.registry' range='[0.0.0,3.5.101.R37x_v20110810-1611)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Extension Registry Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.adapter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.osgi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.internal.registry.spi' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.dynamichelpers' version='3.4.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.spi' version='3.4.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.localization' range='1.1.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.storagemanager' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.registry' version='3.5.101.R37x_v20110810-1611'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.registry;singleton:=true&#xA;Bundle-Version: 3.5.101.R37x_v20110810-1611
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'>
      <update id='org.eclipse.equinox.security' range='[0.0.0,1.1.1.R37x_v20110822-1018)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Java Authentication and Authorization Service (JAAS)'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.ext.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.auth.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.credentials' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.storage.friends' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.credentials' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.auth.module' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.security.storage.provider' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='18'>
        <required namespace='java.package' name='javax.crypto' range='0.0.0'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.callback' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.login' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.spi' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.internal.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.jobs' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.core.runtime.preferences' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.framework.log' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.environment' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='[1.4.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.service.prefs' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security' version='1.1.1.R37x_v20110822-1018'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security;singleton:=true&#xA;Bundle-Version: 1.1.1.R37x_v20110822-1018
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security.ui' version='1.1.0.v20101004'>
      <update id='org.eclipse.equinox.security.ui' range='[0.0.0,1.1.0.v20101004)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.pluginName' value='Equinox Security Default UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' version='1.1.0.v20101004'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security.ui' version='1.1.0.v20101004'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.security.ui' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui.nls' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui.storage' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui.storage.view' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.ui.wizard' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='14'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.preferences' range='[3.2.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.crypto.spec' range='0.0.0'/>
        <required namespace='java.package' name='javax.security.auth.x500' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.internal.service.security' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.debug' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.security' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='org.eclipse.osgi.util' range='[1.1.0,2.0.0)'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='[1.3.3,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security.ui' version='1.1.0.v20101004'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security.ui;singleton:=true&#xA;Bundle-Version: 1.1.0.v20101004
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'>
      <update id='org.eclipse.equinox.security.win32.x86' range='[0.0.0,1.0.200.v20100503)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.fragmentName' value='Windows Data Protection services integration'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.security.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.equinox.security' version='1.0.200.v20100503'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.security' range='[1.0.0,2.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.security.win32.x86' version='1.0.200.v20100503'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.security.win32.x86;singleton:=true&#xA;Bundle-Version: 1.0.200.v20100503&#xA;Fragment-Host: org.eclipse.equinox.security;bundle-version=&quot;[1.0.0,2.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator' version='1.0.200.v20110815-1438'>
      <update id='org.eclipse.equinox.simpleconfigurator' range='[0.0.0,1.0.200.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Simple Configurator'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' version='1.0.200.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' version='1.0.200.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.provisional.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='java.package' name='org.eclipse.osgi.framework.console' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='1.0.0' optional='true'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.resolver' range='1.2.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.packageadmin' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.startlevel' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator' version='1.0.200.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator;singleton:=true&#xA;Bundle-Version: 1.0.200.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0.v20110815-1438'>
      <update id='org.eclipse.equinox.simpleconfigurator.manipulator' range='[0.0.0,2.0.0.v20110815-1438)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Simple Configurator Manipulator'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0.v20110815-1438'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0.v20110815-1438'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.manipulator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.5.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.frameworkadmin' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.equinox' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.frameworkadmin.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.configuratormanipulator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.provisional.frameworkadmin' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.internal.simpleconfigurator.utils' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.osgi.service.datalocation' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.simpleconfigurator.manipulator' version='2.0.0.v20110815-1438'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.simpleconfigurator.manipulator;singleton:=true&#xA;Bundle-Version: 2.0.0.v20110815-1438
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.equinox.util' version='1.0.300.v20110502' singleton='false'>
      <update id='org.eclipse.equinox.util' range='[0.0.0,1.0.300.v20110502)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.bundleVendor' value='Eclipse.org - Equinox'/>
        <property name='df_LT.bundleName' value='Equinox Util Bundle'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.description' value='The Equinox Util Bundle contains services to facilitate bundle developers in their programming, and to lighten resource usage at runtime.'/>
        <property name='org.eclipse.equinox.p2.provider' value='%bundleVendor'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' version='1.0.300.v20110502'/>
        <provided namespace='osgi.bundle' name='org.eclipse.equinox.util' version='1.0.300.v20110502'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.hash' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.threadpool' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.impl.tpt.timer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.pool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.ref' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.threadpool' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.internal.util.timer' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='java.package' name='org.osgi.framework' range='1.3.0'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.service.log' range='1.0.0'/>
        <required namespace='java.package' name='org.osgi.util.tracker' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.equinox.util' version='1.0.300.v20110502'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.equinox.util&#xA;Bundle-Version: 1.0.300.v20110502
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help' version='3.5.100.v20110426'>
      <update id='org.eclipse.help' range='[0.0.0,3.5.100.v20110426)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_plugin_name' value='Help System Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='14'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' version='3.5.100.v20110426'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help' version='3.5.100.v20110426'/>
        <provided namespace='java.package' name='org.eclipse.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.context' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.criteria' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.entityresolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.extension' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.index' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.toc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.util' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.8.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help' version='3.5.100.v20110426'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help; singleton:=true&#xA;Bundle-Version: 3.5.100.v20110426
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.appserver' version='3.1.400.v20110425'>
      <update id='org.eclipse.help.appserver' range='[0.0.0,3.1.400.v20110425)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.appserver_plugin_name' value='Help Application Server'/>
        <property name='org.eclipse.equinox.p2.name' value='%appserver_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.appserver' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.appserver' version='3.1.400.v20110425'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.appserver; singleton:=true&#xA;Bundle-Version: 3.1.400.v20110425
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.base' version='3.6.2.v201202080800'>
      <update id='org.eclipse.help.base' range='[0.0.0,3.6.2.v201202080800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.help_base_plugin_name' value='Help System Base'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_base_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='24'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' version='3.6.2.v201202080800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.base' version='3.6.2.v201202080800'/>
        <provided namespace='java.package' name='org.apache.lucene.demo.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.base' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.remote' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.scope' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.base.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.browser.macosx' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.protocols' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.search.federated' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.server' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.standalone' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.validation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.workingset' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.xhtml' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.server' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.standalone' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.apache.lucene' range='[2.9.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.lucene.analysis' range='[2.9.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ant.core' range='3.2.200' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.6.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.200,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='org.eclipse.equinox.http.jetty' range='0.0.0' optional='true'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.base' version='3.6.2.v201202080800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.base; singleton:=true&#xA;Bundle-Version: 3.6.2.v201202080800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.feature.group' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx' singleton='false'>
      <update id='org.eclipse.help.feature.group' range='[0.0.0,1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Eclipse Help System'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Eclipse help system.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2010 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='19'>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet' range='[2.5.0.v201103041518,2.5.0.v201103041518]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='javax.servlet.jsp' range='[2.0.0.v201101211617,2.0.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.el' range='[1.0.0.v201101211617,1.0.0.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.commons.logging' range='[1.0.4.v201101211617,1.0.4.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.jasper' range='[5.5.17.v201101211617,5.5.17.v201101211617]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.analysis' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.lucene.core' range='[2.9.1.v201101211721,2.9.1.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.jetty' range='[2.0.100.v20110502,2.0.100.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.registry' range='[1.1.100.v20110502,1.1.100.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.http.servlet' range='[1.1.200.v20110502,1.1.200.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper' range='[1.0.300.v20110502,1.0.300.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.jsp.jasper.registry' range='[1.0.200.v20100503,1.0.200.v20100503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.base' range='[3.6.2.v201202080800,3.6.2.v201202080800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' range='[3.5.101.r37_20110819,3.5.101.r37_20110819]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' range='[3.6.1.r37_20110929,3.6.1.r37_20110929]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.server' range='[6.1.23.v201012071420,6.1.23.v201012071420]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.util' range='[6.1.23.v201012071420,6.1.23.v201012071420]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.jar' range='[1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx,1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.help.feature.jar' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx'>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.update.feature.plugin' value='org.eclipse.help.base'/>
        <property name='df_LT.featureName' value='Eclipse Help System'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Eclipse help system.'/>
        <property name='df_LT.copyright' value='Copyright (c) 2008, 2010 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.jar' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.help' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.help' version='1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.help.ui' version='3.5.101.r37_20110819'>
      <update id='org.eclipse.help.ui' range='[0.0.0,3.5.101.r37_20110819)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_system_plugin_name' value='Help System UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_system_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
        <provided namespace='java.package' name='org.eclipse.help.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.browser.embedded' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.dynamic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.ui.internal.views' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.ui' version='3.5.101.r37_20110819'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.ui; singleton:=true&#xA;Bundle-Version: 3.5.101.r37_20110819
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.help.webapp' version='3.6.1.r37_20110929'>
      <update id='org.eclipse.help.webapp' range='[0.0.0,3.6.1.r37_20110929)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.help_webapp_plugin_name' value='Help System Webapp'/>
        <property name='org.eclipse.equinox.p2.name' value='%help_webapp_plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
        <provided namespace='osgi.bundle' name='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.data' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.service' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.servlet' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.internal.webapp.utils' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.help.webapp' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.apache.jasper' range='5.5.17'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.jsp.jasper.registry' range='1.0.100'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.http.registry' range='1.0.200'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='3.8.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.4.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.4.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='1.2.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.help.webapp' version='3.6.1.r37_20110929'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.help.webapp;singleton:=true&#xA;Bundle-Version: 3.6.1.r37_20110929
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface' version='3.7.0.v20110928-1505' singleton='false'>
      <update id='org.eclipse.jface' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='31'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.jface' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.action.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.bindings.keys.formatting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.dialogs.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.fieldassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.provisional.action' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.operation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.preference.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.viewers.deferred' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.window' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.wizard.images' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.osgi.framework' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800' singleton='false'>
      <update id='org.eclipse.jface.databinding' range='[0.0.0,1.5.0.I20100907-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Data Binding for SWT and JFace'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.dialog' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.databinding.wizard' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.provisional.viewers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.databinding.viewers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.databinding' version='1.5.0.I20100907-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.databinding&#xA;Bundle-Version: 1.5.0.I20100907-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jface.text' version='3.7.2.v20111213-1208' singleton='false'>
      <update id='org.eclipse.jface.text' range='[0.0.0,3.7.2.v20111213-1208)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JFace Text'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='27'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
        <provided namespace='java.package' name='org.eclipse.jface.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.contentassist.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.link.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.revisions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.internal.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.formatter' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.hyperlink' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.information' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.presentation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.quickassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.reconciler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.revisions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.rules' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source.projection.images' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates.persistence' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jface.text' version='3.7.2.v20111213-1208'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jface.text&#xA;Bundle-Version: 3.7.2.v20111213-1208
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jsch.core' version='1.1.300.I20110514-0800'>
      <update id='org.eclipse.jsch.core' range='[0.0.0,1.1.300.I20110514-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JSch Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.core' version='1.1.300.I20110514-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jsch.core' version='1.1.300.I20110514-0800'/>
        <provided namespace='java.package' name='org.eclipse.jsch.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jsch.internal.core' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='com.jcraft.jsch' range='[0.1.28,1.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='[1.0.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jsch.core' version='1.1.300.I20110514-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jsch.core;singleton:=true&#xA;Bundle-Version: 1.1.300.I20110514-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.jsch.ui' version='1.1.300.R37x_v20111201-1600'>
      <update id='org.eclipse.jsch.ui' range='[0.0.0,1.1.300.R37x_v20111201-1600)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='JSch UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.ui' version='1.1.300.R37x_v20111201-1600'/>
        <provided namespace='osgi.bundle' name='org.eclipse.jsch.ui' version='1.1.300.R37x_v20111201-1600'/>
        <provided namespace='java.package' name='org.eclipse.jsch.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jsch.internal.ui.preference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jsch.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='0.0.0'/>
        <required namespace='osgi.bundle' name='org.eclipse.jsch.core' range='0.0.0'/>
        <required namespace='osgi.bundle' name='com.jcraft.jsch' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.jsch.ui' version='1.1.300.R37x_v20111201-1600'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.jsch.ui;singleton:=true&#xA;Bundle-Version: 1.1.300.R37x_v20111201-1600
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'>
      <update id='org.eclipse.ltk.core.refactoring' range='[0.0.0,3.5.201.r372_v20111101-0700)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Refactoring Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.participants' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.core.refactoring.resource.undostates' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.text' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ltk.core.refactoring' version='3.5.201.r372_v20111101-0700'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ltk.core.refactoring; singleton:=true&#xA;Bundle-Version: 3.5.201.r372_v20111101-0700
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'>
      <update id='org.eclipse.ltk.ui.refactoring' range='[0.0.0,3.6.0.v20110928-1453)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Refactoring UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='15'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.scripting' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.internal.ui.refactoring.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ltk.ui.refactoring.resource' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.3.200,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.core' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.ui' range='[3.4.100,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ltk.ui.refactoring' version='3.6.0.v20110928-1453'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ltk.ui.refactoring; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110928-1453
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi' version='3.7.2.v20120110-1415'>
      <update id='org.eclipse.osgi' range='[0.0.0,3.7.2.v20120110-1415)' severity='0'/>
      <properties size='6'>
        <property name='df_LT.systemBundle' value='OSGi System Bundle'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.description' value='%systemBundle'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='systembundle'/>
      </properties>
      <provides size='69'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
        <provided namespace='java.package' name='org.eclipse.osgi.event' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.console' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.eventmgr' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.log' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.datalocation' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.debug' version='1.2.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.environment' version='1.3.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.localization' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.pluginconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.resolver' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.runnable' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.urlconversion' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.signedcontent' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.storagemanager' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.util' version='1.1.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework' version='1.6.0'/>
        <provided namespace='java.package' name='org.osgi.framework.launch' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.bundle' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.resolver' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.service' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.framework.hooks.weaving' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.startlevel' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.framework.wiring' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.condpermadmin' version='1.1.1'/>
        <provided namespace='java.package' name='org.osgi.service.framework' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.packageadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.permissionadmin' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.startlevel' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.url' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.util.tracker' version='1.5.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.core.runtime.internal.stats' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.bundlefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.hooks' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.baseadaptor.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.adaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.debug' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleentry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.bundleresource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.protocol.reference' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.internal.reliablefile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.framework.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.baseadaptor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.loader.buddy' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.module' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.profile' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.resolver' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.serviceregistry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.permadmin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.service.security' version='1.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.provisional.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.service.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.internal.signedcontent' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.osgi.service.internal.composite' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.equinox.log.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi' version='3.7.2.v20120110-1415'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi; singleton:=true&#xA;Bundle-Version: 3.7.2.v20120110-1415
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.services' version='3.3.0.v20110513' singleton='false'>
      <update id='org.eclipse.osgi.services' range='[0.0.0,3.3.0.v20110513)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.osgiServicesDes' value='OSGi Service Platform Release 4.2.0 Service Interfaces and Classes'/>
        <property name='df_LT.osgiServices' value='OSGi Release 4.2.0 Services'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiServices'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiServicesDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
        <provided namespace='java.package' name='org.osgi.service.cm' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.component' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.device' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.event' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.http' version='1.2.1'/>
        <provided namespace='java.package' name='org.osgi.service.io' version='1.0.0'/>
        <provided namespace='java.package' name='org.osgi.service.log' version='1.3.0'/>
        <provided namespace='java.package' name='org.osgi.service.metatype' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.provisioning' version='1.2.0'/>
        <provided namespace='java.package' name='org.osgi.service.upnp' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.useradmin' version='1.1.0'/>
        <provided namespace='java.package' name='org.osgi.service.wireadmin' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='16'>
        <required namespace='java.package' name='org.osgi.framework' range='1.2.0'/>
        <required namespace='java.package' name='org.osgi.service.http' range='[1.2.1,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.io' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='javax.microedition.io' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.useradmin' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.component' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.log' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.device' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.service.wireadmin' range='[1.0.0,1.1.0)'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.upnp' range='[1.1.0,1.2.0)'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.osgi.service.cm' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.metatype' range='[1.2.0,1.3.0)'/>
        <required namespace='java.package' name='org.osgi.service.event' range='[1.3.0,1.4.0)'/>
        <required namespace='java.package' name='org.osgi.service.provisioning' range='[1.2.0,1.3.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.services' version='3.3.0.v20110513'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.services&#xA;Bundle-Version: 3.3.0.v20110513
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.osgi.util' version='3.2.200.v20110110' singleton='false'>
      <update id='org.eclipse.osgi.util' range='[0.0.0,3.2.200.v20110110)' severity='0'/>
      <properties size='8'>
        <property name='df_LT.osgiUtil' value='OSGi Release 4.2.0 Utility Classes'/>
        <property name='df_LT.eclipse.org' value='Eclipse.org - Equinox'/>
        <property name='df_LT.osgiUtilDes' value='OSGi Service Platform Release 4.2.0 Utility Classes'/>
        <property name='org.eclipse.equinox.p2.name' value='%osgiUtil'/>
        <property name='org.eclipse.equinox.p2.description' value='%osgiUtilDes'/>
        <property name='org.eclipse.equinox.p2.provider' value='%eclipse.org'/>
        <property name='org.eclipse.equinox.p2.contact' value='www.eclipse.org'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' version='3.2.200.v20110110'/>
        <provided namespace='osgi.bundle' name='org.eclipse.osgi.util' version='3.2.200.v20110110'/>
        <provided namespace='java.package' name='org.osgi.util.measurement' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.position' version='1.0.1'/>
        <provided namespace='java.package' name='org.osgi.util.xml' version='1.0.1'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='java.package' name='org.osgi.framework' range='1.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0' optional='true'/>
        <required namespace='java.package' name='org.osgi.util.measurement' range='[1.0.1,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.position' range='[1.0.1,1.2.0)'/>
        <required namespace='java.package' name='org.osgi.util.xml' range='[1.0.1,1.2.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.osgi.util' version='3.2.200.v20110110'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.osgi.util&#xA;Bundle-Version: 3.2.200.v20110110
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.platform' version='3.7.2.v201202080800'>
      <update id='org.eclipse.platform' range='[0.0.0,3.7.2.v201202080800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Platform'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform' version='3.7.2.v201202080800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.platform' version='3.7.2.v201202080800'/>
        <provided namespace='java.package' name='org.eclipse.platform.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.intro' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.cheatsheets' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.platform' version='3.7.2.v201202080800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.platform; singleton:=true&#xA;Bundle-Version: 3.7.2.v201202080800
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.platform.doc.user' version='3.7.1.r372_v20111202'>
      <update id='org.eclipse.platform.doc.user' range='[0.0.0,3.7.1.r372_v20111202)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse Workbench User Guide'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.user' version='3.7.1.r372_v20111202'/>
        <provided namespace='osgi.bundle' name='org.eclipse.platform.doc.user' version='3.7.1.r372_v20111202'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.platform.doc.user' version='3.7.1.r372_v20111202'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.platform.doc.user; singleton:=true&#xA;Bundle-Version: 3.7.1.r372_v20111202
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.platform.feature.group' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q' singleton='false'>
      <update id='org.eclipse.platform.feature.group' range='[0.0.0,3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Eclipse Platform'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Common OS-independent base of the Eclipse platform (binary runtime and user documentation).'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2011 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='80'>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' range='[3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272,3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl,2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl]' optional='true'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.feature.group' range='[1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx,1.3.0.v20110530-0844-7i7uFFmFFl8nvqbDpEqTvx]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.apache.ant' range='[1.8.2.v20120109-1030,1.8.2.v20120109-1030]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ant.core' range='[3.2.302.v20120110-1739,3.2.302.v20120110-1739]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.jcraft.jsch' range='[0.1.44.v201101211721,0.1.44.v201101211721]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.core' range='[3.5.200.I20110208-0800,3.5.200.I20110208-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare' range='[3.5.202.R37x_v20111109-0800,3.5.202.R37x_v20111109-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.compare.win32' range='[1.0.200.I20110510-0800,1.0.200.I20110510-0800]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.boot' range='[3.1.200.v20100505,3.1.200.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filebuffers' range='[3.5.200.v20110928-1504,3.5.200.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem' range='[1.3.100.v20110423-0524,1.3.100.v20110423-0524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net' range='[1.2.100.I20110511-0800,1.2.100.I20110511-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86' range='[1.0.100.I20110331-0827,1.0.100.I20110331-0827]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86_64' range='[1.1.0.I20110331-0827,1.1.0.I20110331-0827]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.win32.x86_64' range='[1.0.100.I20110331-0827,1.0.100.I20110331-0827]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.net.linux.x86' range='[1.1.200.I20110419-0800,1.1.200.I20110419-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources' range='[3.7.101.v20120125-1505,3.7.101.v20120125-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility' range='[3.2.100.v20100505,3.2.100.v20100505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.registry' range='[3.5.0.v20110505,3.5.0.v20110505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.util' range='[3.2.200.v20110110,3.2.200.v20110110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.core' range='[3.7.1.v20111129-2031,3.7.1.v20111129-2031]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.debug.ui' range='[3.7.102.v20111129-1423_r372,3.7.102.v20111129-1423_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.event' range='[1.2.100.v20110502,1.2.100.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help.appserver' range='[3.1.400.v20110425,3.1.400.v20110425]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.core.refactoring' range='[3.5.201.r372_v20111101-0700,3.5.201.r372_v20111101-0700]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ltk.ui.refactoring' range='[3.6.0.v20110928-1453,3.6.0.v20110928-1453]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform' range='[3.7.2.v201202080800,3.7.2.v201202080800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.doc.user' range='[3.7.1.r372_v20111202,3.7.1.r372_v20111202]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' range='[3.6.0.I20110525-0800,3.6.0.I20110525-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' range='[3.6.101.R37x_v20111109-0800,3.6.101.R37x_v20111109-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' range='[3.5.101.v20110928-1504,3.5.101.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.text' range='[3.7.2.v20111213-1208,3.7.2.v20111213-1208]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.core' range='[1.1.300.I20110514-0800,1.1.300.I20110514-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jsch.ui' range='[1.1.300.R37x_v20111201-1600,1.1.300.R37x_v20111201-1600]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' range='[3.5.100.v20111007_r372,3.5.100.v20111007_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.presentations.r21' range='[3.2.200.I20100517-1500,3.2.200.I20100517-1500]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro' range='[3.4.100.v20110425,3.4.100.v20110425]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.universal' range='[3.2.500.v20110510,3.2.500.v20110510]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cheatsheets' range='[3.4.100.v20110425,3.4.100.v20110425]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' range='[3.3.101.v20111019-1723,3.3.101.v20111019-1723]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' range='[3.5.101.v20120106-1355,3.5.101.v20120106-1355]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' range='[3.4.300.v20110928-1505,3.4.300.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' range='[1.2.100.v20111208-1155,1.2.100.v20111208-1155]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' range='[3.6.0.v20110928-1505,3.6.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' range='[3.7.0.v20110928-1504,3.7.0.v20110928-1504]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.externaltools' range='[3.2.0.v20111007_r372,3.2.0.v20111007_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' range='[1.0.300.I20110306-2000,1.0.300.I20110306-2000]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' range='[3.2.200.v20110928-1505,3.2.200.v20110928-1505]'>
          <filter>
            (osgi.ws=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core' range='[3.2.500.v20110330,3.2.500.v20110330]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.scheduler' range='[3.2.300.v20100512,3.2.300.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.ui' range='[3.2.300.v20100512,3.2.300.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.compatibility' range='[3.2.100.I20110413-1600,3.2.100.I20110413-1600]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.aix.ppc' range='[1.1.0.v20110423-0524,1.1.0.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.hpux.ia64_32' range='[1.0.100.v20110423-0524,1.0.100.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86' range='[1.4.0.v20110423-0524,1.4.0.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.linux.x86_64' range='[1.2.0.v20110423-0524,1.2.0.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.solaris.sparc' range='[1.2.0.v20110423-0524,1.2.0.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.macosx' range='[1.3.0.v20110423-0524,1.3.0.v20110423-0524]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86' range='[1.1.300.v20110423-0524,1.1.300.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.resources.win32.x86' range='[3.5.100.v20110423-0524,3.5.100.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.filesystem.win32.x86_64' range='[1.1.300.v20110423-0524,1.1.300.v20110423-0524]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.variables' range='[3.2.500.v20110928-1503,3.2.500.v20110928-1503]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' range='[3.5.101.v20111011-1919,3.5.101.v20111011-1919]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core.linux' range='[3.2.200.v20100512,3.2.200.v20100512]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core.win32' range='[3.2.200.v20100512,3.2.200.v20100512]'>
          <filter>
            (osgi.os=win32)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' range='[3.5.200.v20110928-1505,3.5.200.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security' range='[1.1.1.R37x_v20110822-1018,1.1.1.R37x_v20110822-1018]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.ui' range='[1.1.0.v20101004,1.1.0.v20101004]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86' range='[1.0.200.v20100503,1.0.200.v20100503]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.win32.x86_64' range='[1.0.0.v20110502,1.0.0.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.100.100.v20100503,1.100.100.v20100503]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.100.100.v20100503,1.100.100.v20100503]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.security.macosx' range='[1.100.100.v20100503,1.100.100.v20100503]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.externaltools' range='[1.0.100.v20111007_r372,1.0.100.v20111007_r372]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.jar' range='[3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q,3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' range='[3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q,3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform.feature.jar' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'>
      <properties size='8'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='df_LT.featureName' value='Eclipse Platform'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Common OS-independent base of the Eclipse platform (binary runtime and user documentation).'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2011 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.jar' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.platform' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.platform' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.platform.ide' version='3.7.2.M20120208-0800'>
      <update id='org.eclipse.platform.ide' range='0.0.0' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='Eclipse Platform'/>
        <property name='lineUp' value='true'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
      </properties>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.ide' version='3.7.2.M20120208-0800'/>
      </provides>
      <requires size='11'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.configuration' range='[1.0.0,1.0.0]'>
          <filter>
            (!(osgi.os=macosx))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='config.a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' range='[1.0.0,1.0.0]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.configuration' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.p2.user.ui.feature.group' range='[2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl,2.1.2.R37x_v20110815-1155-6-Bk8pYWZz0qUTX5I15GZWwbXkrl]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration.feature.group' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform.feature.group' range='[3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q,3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.configuration.macosx' range='[1.0.0,1.0.0]'>
          <filter>
            (osgi.os=macosx)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='a.jre.javase' range='[1.6.0,1.6.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' range='[1.0.0,1.0.0]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' range='[1.0.0,1.0.0]'/>
      </requires>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='configure'>
            addRepository(type:0,location:http${#58}//download.eclipse.org/eclipse/updates/3.7,name:The Eclipse Project Updates);addRepository(type:1,location:http${#58}//download.eclipse.org/eclipse/updates/3.7,name:The Eclipse Project Updates);addRepository(type:0,location:http${#58}//download.eclipse.org/releases/indigo,name:Indigo);addRepository(type:1,location:http${#58}//download.eclipse.org/releases/indigo,name:Indigo);mkdir(path:${installFolder}/dropins);
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='http://eclipse.org/legal/epl/notice.php' url='http://eclipse.org/legal/epl/notice.php'>
          Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;      - Content may be structured and packaged into modules to facilitate delivering,&#xA;         extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;         plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;       - Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;         in a directory named &quot;plugins&quot;.&#xA;       - A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;         Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;         Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;         numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;       - Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;         named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;       - The top-level (root) directory&#xA;       - Plug-in and Fragment directories&#xA;       - Inside Plug-ins and Fragments packaged as JARs&#xA;       - Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;       - Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;       - Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;       - Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;       - Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;       - Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;       - Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;       - Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;       1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;          the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;          extending or updating the functionality of an Eclipse-based product.&#xA;       2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;          Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;       3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;          govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;          Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;          with the Specification. Such Installable Software Agreement must inform the user of the&#xA;          terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;          the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;          indication of agreement by the user, the provisioning Technology will complete installation&#xA;          of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.
        </license>
      </licenses>
    </unit>
    <unit id='org.eclipse.platform_root' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.platform_root' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.platform_root' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp' version='3.7.2.v201202080800'>
      <update id='org.eclipse.rcp' range='[0.0.0,3.7.2.v201202080800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Eclipse RCP'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp' version='3.7.2.v201202080800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.rcp' version='3.7.2.v201202080800'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.rcp' version='3.7.2.v201202080800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.rcp; singleton:=true&#xA;Bundle-Version: 3.7.2.v201202080800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.configuration.feature.group' version='1.0.0.M20120208-0800' singleton='false'>
      <update id='org.eclipse.rcp.configuration.feature.group' range='[0.0.0,1.0.0.M20120208-0800)' severity='0'/>
      <properties size='7'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='false'/>
        <property name='df_LT.featureName' value='Eclipse Product Configuration'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Configuration information for the Eclipse product'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration.feature.group' version='1.0.0.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='48'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.ppc64' range='[1.0.100.v20110505,1.0.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.linux.ppc64' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.solaris.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.solaris.sparc' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.carbon.macosx.ppc' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.aix.ppc' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.hpux.ia64_32' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.solaris.sparc' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.linux.x86' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.s390x' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.ppc64' range='[1.0.100.v20110505,1.0.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.solaris.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.carbon.macosx' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=carbon)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.hpux.ia64_32' range='[1.0.0.v20110502,1.0.0.v20110502]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.aix.ppc64' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.aix.ppc' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.solaris.x86' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.linux.s390' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.linux.s390x' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.s390x' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.aix.ppc64' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.hpux.ia64_32' range='[1.0.0.v20110502,1.0.0.v20110502]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.linux.x86_64' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.win32.win32.x86' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.carbon.macosx' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=carbon)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.s390' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa)(|(osgi.arch=ppc)(osgi.arch=x86)))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.carbon.macosx.x86' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.cocoa.macosx.x86_64' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.aix.ppc' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.cocoa.macosx.x86' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.gtk.solaris.sparc' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.win32.win32.x86_64' range='[1.0.0.M20120208-0800,1.0.0.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.gtk.aix.ppc64' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.s390' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure' import='org.eclipse.equinox.p2.touchpoint.eclipse.setLauncherName'>
            setLauncherName();
          </instruction>
          <instruction key='configure' import='org.eclipse.equinox.p2.touchpoint.eclipse.setLauncherName'>
            setLauncherName(name:eclipse);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20120208-0800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20120208-0800'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20120208-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.rcp.feature.group' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272' singleton='false'>
      <update id='org.eclipse.rcp.feature.group' range='[0.0.0,3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272)' severity='0'/>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.type.group' value='true'/>
        <property name='df_LT.featureName' value='Eclipse RCP'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Rich Client Platform'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2012 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.group' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='66'>
        <required namespace='org.eclipse.equinox.p2.iu' name='com.ibm.icu' range='[4.4.2.v20110823,4.4.2.v20110823]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.commands' range='[3.6.0.I20110111-0800,3.6.0.I20110111-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding' range='[1.4.0.I20110111-0800,1.4.0.I20110111-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.observable' range='[1.4.0.I20110222-0800,1.4.0.I20110222-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.property' range='[1.4.0.I20110222-0800,1.4.0.I20110222-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.databinding.beans' range='[1.2.100.I20100824-0800,1.2.100.I20100824-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.jobs' range='[3.5.101.v20120113-1953,3.5.101.v20120113-1953]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.expressions' range='[3.4.300.v20110228,3.4.300.v20110228]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime' range='[3.7.0.v20110110,3.7.0.v20110110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.runtime.compatibility.auth' range='[3.2.200.v20110110,3.2.200.v20110110]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi' range='[3.7.2.v20120110-1415,3.7.2.v20120110-1415]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.osgi.services' range='[3.3.0.v20110513,3.3.0.v20110513]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.help' range='[3.5.100.v20110426,3.5.100.v20110426]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' range='[3.7.2.v3740f,3.7.2.v3740f]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.jface.databinding' range='[1.5.0.I20100907-0800,1.5.0.I20100907-0800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' range='[3.7.0.v20110928-1505,3.7.0.v20110928-1505]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' range='[3.7.1.v20120104-1859,3.7.1.v20120104-1859]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.carbon' range='[4.0.100.I20101109-0800,4.0.100.I20101109-0800]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cocoa' range='[1.1.0.I20101109-0800,1.1.0.I20101109-0800]'>
          <filter>
            (&amp;(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' range='[3.3.100.v20100512,3.3.100.v20100512]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.simpleconfigurator' range='[1.0.200.v20110815-1438,1.0.200.v20110815-1438]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86_64' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.s390x' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.s390' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.solaris.sparc' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.solaris.x86' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.ppc64' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.linux.x86_64' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.carbon.macosx' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.carbon.macosx' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.cocoa.macosx.x86_64' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.aix.ppc' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.aix.ppc64' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.gtk.hpux.ia64_32' range='[3.7.2.v3740f,3.7.2.v3740f]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp' range='[3.7.2.v201202080800,3.7.2.v201202080800]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.core.contenttype' range='[3.4.100.v20110423-0524,3.4.100.v20110423-0524]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.app' range='[1.3.100.v20110321,1.3.100.v20110321]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.common' range='[3.6.0.v20110523,3.6.0.v20110523]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.ds' range='[1.3.1.R37x_v20110701,1.3.1.R37x_v20110701]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.util' range='[1.0.300.v20110502,1.0.300.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.preferences' range='[3.4.2.v20120111-2020,3.4.2.v20120111-2020]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.registry' range='[3.5.101.R37x_v20110810-1611,3.5.101.R37x_v20110810-1611]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]'/>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.solaris.sparc' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.solaris.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.carbon.macosx' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.carbon.macosx' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.cocoa.macosx.x86_64' range='[1.1.101.v20120109-1504,1.1.101.v20120109-1504]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.ppc64' range='[1.0.100.v20110505,1.0.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.s390x' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.s390' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.linux.x86_64' range='[1.1.100.v20110505,1.1.100.v20110505]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.aix.ppc' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.gtk.aix.ppc64' range='[1.1.0.v20110530,1.1.0.v20110530]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.equinox.launcher.win32.win32.x86_64' range='[1.1.100.v20110502,1.1.100.v20110502]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.jar' range='[3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272,3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272]'>
          <filter>
            (org.eclipse.update.install.features=true)
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' range='[3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272,3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272]'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.rcp.feature.jar' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'>
      <properties size='9'>
        <property name='org.eclipse.equinox.p2.name' value='%featureName'/>
        <property name='org.eclipse.equinox.p2.description' value='%description'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.update.feature.plugin' value='org.eclipse.rcp'/>
        <property name='df_LT.featureName' value='Eclipse RCP'/>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.description' value='Rich Client Platform'/>
        <property name='df_LT.copyright' value='Copyright (c) 2000, 2012 IBM Corporation and others.&#xA;All rights reserved. This program and the accompanying materials&#xA;are made available under the terms of the Eclipse Public License v1.0&#xA;which accompanies this distribution, and is available at&#xA;http://www.eclipse.org/legal/epl-v10.html&#xA;&#xA;Contributors:&#xA;IBM Corporation - initial API and implementation'/>
        <property name='df_LT.license' value='Eclipse Foundation Software User Agreement&#xA;February 1, 2011&#xA;&#xA;Usage Of Content&#xA;&#xA;THE ECLIPSE FOUNDATION MAKES AVAILABLE SOFTWARE, DOCUMENTATION, INFORMATION AND/OR&#xA;OTHER MATERIALS FOR OPEN SOURCE PROJECTS (COLLECTIVELY &quot;CONTENT&quot;).&#xA;USE OF THE CONTENT IS GOVERNED BY THE TERMS AND CONDITIONS OF THIS&#xA;AGREEMENT AND/OR THE TERMS AND CONDITIONS OF LICENSE AGREEMENTS OR&#xA;NOTICES INDICATED OR REFERENCED BELOW.  BY USING THE CONTENT, YOU&#xA;AGREE THAT YOUR USE OF THE CONTENT IS GOVERNED BY THIS AGREEMENT&#xA;AND/OR THE TERMS AND CONDITIONS OF ANY APPLICABLE LICENSE AGREEMENTS&#xA;OR NOTICES INDICATED OR REFERENCED BELOW.  IF YOU DO NOT AGREE TO THE&#xA;TERMS AND CONDITIONS OF THIS AGREEMENT AND THE TERMS AND CONDITIONS&#xA;OF ANY APPLICABLE LICENSE AGREEMENTS OR NOTICES INDICATED OR REFERENCED&#xA;BELOW, THEN YOU MAY NOT USE THE CONTENT.&#xA;&#xA;Applicable Licenses&#xA;&#xA;Unless otherwise indicated, all Content made available by the&#xA;Eclipse Foundation is provided to you under the terms and conditions of&#xA;the Eclipse Public License Version 1.0 (&quot;EPL&quot;). A copy of the EPL is&#xA;provided with this Content and is also available at http://www.eclipse.org/legal/epl-v10.html.&#xA;For purposes of the EPL, &quot;Program&quot; will mean the Content.&#xA;&#xA;Content includes, but is not limited to, source code, object code,&#xA;documentation and other files maintained in the Eclipse Foundation source code&#xA;repository (&quot;Repository&quot;) in software modules (&quot;Modules&quot;) and made available&#xA;as downloadable archives (&quot;Downloads&quot;).&#xA;&#xA;- Content may be structured and packaged into modules to facilitate delivering,&#xA;extending, and upgrading the Content. Typical modules may include plug-ins (&quot;Plug-ins&quot;),&#xA;plug-in fragments (&quot;Fragments&quot;), and features (&quot;Features&quot;).&#xA;- Each Plug-in or Fragment may be packaged as a sub-directory or JAR (Java(TM) ARchive)&#xA;in a directory named &quot;plugins&quot;.&#xA;- A Feature is a bundle of one or more Plug-ins and/or Fragments and associated material.&#xA;Each Feature may be packaged as a sub-directory in a directory named &quot;features&quot;.&#xA;Within a Feature, files named &quot;feature.xml&quot; may contain a list of the names and version&#xA;numbers of the Plug-ins and/or Fragments associated with that Feature.&#xA;- Features may also include other Features (&quot;Included Features&quot;). Within a Feature, files&#xA;named &quot;feature.xml&quot; may contain a list of the names and version numbers of Included Features.&#xA;&#xA;The terms and conditions governing Plug-ins and Fragments should be&#xA;contained in files named &quot;about.html&quot; (&quot;Abouts&quot;). The terms and&#xA;conditions governing Features and Included Features should be contained&#xA;in files named &quot;license.html&quot; (&quot;Feature Licenses&quot;). Abouts and Feature&#xA;Licenses may be located in any directory of a Download or Module&#xA;including, but not limited to the following locations:&#xA;&#xA;- The top-level (root) directory&#xA;- Plug-in and Fragment directories&#xA;- Inside Plug-ins and Fragments packaged as JARs&#xA;- Sub-directories of the directory named &quot;src&quot; of certain Plug-ins&#xA;- Feature directories&#xA;&#xA;Note: if a Feature made available by the Eclipse Foundation is installed using the&#xA;Provisioning Technology (as defined below), you must agree to a license (&quot;Feature &#xA;Update License&quot;) during the installation process. If the Feature contains&#xA;Included Features, the Feature Update License should either provide you&#xA;with the terms and conditions governing the Included Features or inform&#xA;you where you can locate them. Feature Update Licenses may be found in&#xA;the &quot;license&quot; property of files named &quot;feature.properties&quot; found within a Feature.&#xA;Such Abouts, Feature Licenses, and Feature Update Licenses contain the&#xA;terms and conditions (or references to such terms and conditions) that&#xA;govern your use of the associated Content in that directory.&#xA;&#xA;THE ABOUTS, FEATURE LICENSES, AND FEATURE UPDATE LICENSES MAY REFER&#xA;TO THE EPL OR OTHER LICENSE AGREEMENTS, NOTICES OR TERMS AND CONDITIONS.&#xA;SOME OF THESE OTHER LICENSE AGREEMENTS MAY INCLUDE (BUT ARE NOT LIMITED TO):&#xA;&#xA;- Eclipse Distribution License Version 1.0 (available at http://www.eclipse.org/licenses/edl-v1.0.html)&#xA;- Common Public License Version 1.0 (available at http://www.eclipse.org/legal/cpl-v10.html)&#xA;- Apache Software License 1.1 (available at http://www.apache.org/licenses/LICENSE)&#xA;- Apache Software License 2.0 (available at http://www.apache.org/licenses/LICENSE-2.0)&#xA;- Metro Link Public License 1.00 (available at http://www.opengroup.org/openmotif/supporters/metrolink/license.html)&#xA;- Mozilla Public License Version 1.1 (available at http://www.mozilla.org/MPL/MPL-1.1.html)&#xA;&#xA;IT IS YOUR OBLIGATION TO READ AND ACCEPT ALL SUCH TERMS AND CONDITIONS PRIOR&#xA;TO USE OF THE CONTENT. If no About, Feature License, or Feature Update License&#xA;is provided, please contact the Eclipse Foundation to determine what terms and conditions&#xA;govern that particular Content.&#xA;&#xA;&#xA;Use of Provisioning Technology&#xA;&#xA;The Eclipse Foundation makes available provisioning software, examples of which include,&#xA;but are not limited to, p2 and the Eclipse Update Manager (&quot;Provisioning Technology&quot;) for&#xA;the purpose of allowing users to install software, documentation, information and/or&#xA;other materials (collectively &quot;Installable Software&quot;). This capability is provided with&#xA;the intent of allowing such users to install, extend and update Eclipse-based products.&#xA;Information about packaging Installable Software is available at&#xA;http://eclipse.org/equinox/p2/repository_packaging.html (&quot;Specification&quot;).&#xA;&#xA;You may use Provisioning Technology to allow other parties to install Installable Software.&#xA;You shall be responsible for enabling the applicable license agreements relating to the&#xA;Installable Software to be presented to, and accepted by, the users of the Provisioning Technology&#xA;in accordance with the Specification. By using Provisioning Technology in such a manner and&#xA;making it available in accordance with the Specification, you further acknowledge your&#xA;agreement to, and the acquisition of all necessary rights to permit the following:&#xA;&#xA;1. A series of actions may occur (&quot;Provisioning Process&quot;) in which a user may execute&#xA;the Provisioning Technology on a machine (&quot;Target Machine&quot;) with the intent of installing,&#xA;extending or updating the functionality of an Eclipse-based product.&#xA;2. During the Provisioning Process, the Provisioning Technology may cause third party&#xA;Installable Software or a portion thereof to be accessed and copied to the Target Machine.&#xA;3. Pursuant to the Specification, you will provide to the user the terms and conditions that&#xA;govern the use of the Installable Software (&quot;Installable Software Agreement&quot;) and such&#xA;Installable Software Agreement shall be accessed from the Target Machine in accordance&#xA;with the Specification. Such Installable Software Agreement must inform the user of the&#xA;terms and conditions that govern the Installable Software and must solicit acceptance by&#xA;the end user in the manner prescribed in such Installable Software Agreement. Upon such&#xA;indication of agreement by the user, the provisioning Technology will complete installation&#xA;of the Installable Software.&#xA;&#xA;Cryptography&#xA;&#xA;Content may contain encryption software. The country in which you are&#xA;currently may have restrictions on the import, possession, and use,&#xA;and/or re-export to another country, of encryption software. BEFORE&#xA;using any encryption software, please check the country&apos;s laws,&#xA;regulations and policies concerning the import, possession, or use, and&#xA;re-export of encryption software, to see if this is permitted.&#xA;&#xA;Java and all Java-based trademarks are trademarks of Oracle Corporation in the United States, other countries, or both.'/>
      </properties>
      <provides size='3'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp.feature.jar' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' version='1.0.0'/>
        <provided namespace='org.eclipse.update.feature' name='org.eclipse.rcp' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
      </provides>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <artifacts size='1'>
        <artifact classifier='org.eclipse.update.feature' id='org.eclipse.rcp' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
      <licenses size='1'>
        <license uri='%25licenseURL' url='%25licenseURL'>
          %license
        </license>
      </licenses>
      <copyright>
        %copyright
      </copyright>
    </unit>
    <unit id='org.eclipse.rcp_root' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.rcp_root' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='binary' id='org.eclipse.rcp_root' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.native' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            unzip(source:@artifact, target:${installFolder});
          </instruction>
          <instruction key='uninstall'>
            cleanupzip(source:@artifact, target:${installFolder});
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.search' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.search' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Search Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.search' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.search' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.search.core.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.core.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.internal.ui.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.basic.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.search2.internal.ui.text2' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.search' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.search; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt' version='3.7.2.v3740f'>
      <update id='org.eclipse.swt' range='[0.0.0,3.7.2.v3740f)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Standard Widget Toolkit'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='java.package' name='org.eclipse.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.accessibility' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.awt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.custom' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.graphics' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.opengl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.printing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.program' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.image' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.theme' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='java.package' name='org.eclipse.swt.accessibility2' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mozilla.xpcom' range='0.0.0' optional='true' greedy='false'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt' version='3.7.2.v3740f'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt; singleton:=true&#xA;Bundle-Version: 3.7.2.v3740f
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'>
      <update id='org.eclipse.swt.win32.win32.x86' range='[0.0.0,3.7.2.v3740f)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Standard Widget Toolkit for Windows'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
        <provided namespace='osgi.bundle' name='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
        <provided namespace='java.package' name='org.eclipse.swt.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.gdip' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.ole.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.win32' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.swt.internal.opengl.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.swt' version='3.7.2.v3740f'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.0.0,4.0.0)'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.swt.win32.win32.x86' version='3.7.2.v3740f'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.swt.win32.win32.x86; singleton:=true&#xA;Bundle-Version: 3.7.2.v3740f&#xA;Fragment-Host: org.eclipse.swt; bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.team.core' version='3.6.0.I20110525-0800'>
      <update id='org.eclipse.team.core' range='[0.0.0,3.6.0.I20110525-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Team Support Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='21'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
        <provided namespace='java.package' name='org.eclipse.team.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.diff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.diff.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.history.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.importing.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.mapping.provider' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.subscribers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.synchronize' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.core.variants' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.importing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.streams' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.core.subscribers' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.1.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.team.core' version='3.6.0.I20110525-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.team.core; singleton:=true&#xA;Bundle-Version: 3.6.0.I20110525-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'>
      <update id='org.eclipse.team.ui' range='[0.0.0,3.6.101.R37x_v20111109-0800)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Team Support UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
        <provided namespace='osgi.bundle' name='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.synchronize.patch' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.internal.ui.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.history' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.mapping' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.team.ui.synchronize' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.3.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.team.core' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.editors' range='[3.3.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.team.ui' version='3.6.101.R37x_v20111109-0800'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.team.ui; singleton:=true&#xA;Bundle-Version: 3.6.101.R37x_v20111109-0800
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.text' version='3.5.101.v20110928-1504' singleton='false'>
      <update id='org.eclipse.text' range='[0.0.0,3.5.101.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Text'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.text' version='3.5.101.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.text' version='3.5.101.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.jface.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.projection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.source' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.jface.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.edits' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.text.undo' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='4'>
        <required namespace='osgi.bundle' name='org.eclipse.core.commands' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.text' version='3.5.101.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.text&#xA;Bundle-Version: 3.5.101.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui' version='3.7.0.v20110928-1505'>
      <update id='org.eclipse.ui' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.browser' version='3.3.101.v20111019-1723'>
      <update id='org.eclipse.ui.browser' range='[0.0.0,3.3.101.v20111019-1723)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Browser Support'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.browser' version='3.3.101.v20111019-1723'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.browser' version='3.3.101.v20111019-1723'/>
        <provided namespace='java.package' name='org.eclipse.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser.browsers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser.macosx' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.browser' version='3.3.101.v20111019-1723'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.browser; singleton:=true&#xA;Bundle-Version: 3.3.101.v20111019-1723
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.cheatsheets' version='3.4.100.v20110425'>
      <update id='org.eclipse.ui.cheatsheets' range='[0.0.0,3.4.100.v20110425)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.PLUGIN_NAME' value='Cheat Sheets'/>
        <property name='df_LT.PROVIDER_NAME' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%PLUGIN_NAME'/>
        <property name='org.eclipse.equinox.p2.provider' value='%PROVIDER_NAME'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='18'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.cheatsheets' version='3.4.100.v20110425'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.cheatsheets' version='3.4.100.v20110425'/>
        <provided namespace='java.package' name='org.eclipse.ui.cheatsheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.composite.explorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.composite.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.composite.parser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.composite.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.data' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.state' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.cheatsheets.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.cheatsheets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='11'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.ui' range='[3.5.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.cheatsheets' version='3.4.100.v20110425'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.cheatsheets; singleton:=true&#xA;Bundle-Version: 3.4.100.v20110425
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.console' version='3.5.100.v20111007_r372'>
      <update id='org.eclipse.ui.console' range='[0.0.0,3.5.100.v20111007_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Console'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
        <provided namespace='java.package' name='org.eclipse.ui.console' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.console.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.console' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.console' version='3.5.100.v20111007_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.console; singleton:=true&#xA;Bundle-Version: 3.5.100.v20111007_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.ui.editors' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Default Text Editor'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.ui.editors.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.editors.text.templates' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editors.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editors.text' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filebuffers' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.editors' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.editors; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.externaltools' version='3.2.0.v20111007_r372'>
      <update id='org.eclipse.ui.externaltools' range='[0.0.0,3.2.0.v20111007_r372)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='External Tools'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.externaltools' version='3.2.0.v20111007_r372'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.externaltools' version='3.2.0.v20111007_r372'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.launchConfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.menu' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.program.launchConfigurations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.externaltools.internal.variables' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.variables' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.core' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.debug.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.externaltools' range='[1.0.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.externaltools' version='3.2.0.v20111007_r372'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.externaltools; singleton:=true&#xA;Bundle-Version: 3.2.0.v20111007_r372
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.forms' version='3.5.101.v20111011-1919' singleton='false'>
      <update id='org.eclipse.ui.forms' range='[0.0.0,3.5.101.v20111011-1919)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.name' value='Eclipse Forms'/>
        <property name='df_LT.provider-name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider-name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.editor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.events' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.forms.widgets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.forms' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.forms.widgets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)' optional='true'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.forms' version='3.5.101.v20111011-1919'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.forms&#xA;Bundle-Version: 3.5.101.v20111011-1919
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'>
      <update id='org.eclipse.ui.ide' range='[0.0.0,3.7.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse IDE UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='40'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.fileSystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.ide.undo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.filesystem' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.undo' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.bookmarkexplorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.markers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.tasklist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.newresource' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.bookmarkexplorer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.markers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.markers.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.tasklist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards.datatransfer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards.newresource' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.7.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.engine' range='[2.0.0,3.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.metadata' range='[2.0.0,3.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.ide' version='3.7.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.ide; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.ide.application' version='1.0.300.I20110306-2000'>
      <update id='org.eclipse.ui.ide.application' range='[0.0.0,1.0.300.I20110306-2000)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Eclipse IDE UI Application'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.ide.application' version='1.0.300.I20110306-2000'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.ide.application' version='1.0.300.I20110306-2000'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.ide.application.dialogs' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='[1.0.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.filesystem' range='1.3.0'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.ide.application' version='1.0.300.I20110306-2000'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.ide.application;singleton:=true&#xA;Bundle-Version: 1.0.300.I20110306-2000
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.intro' version='3.4.100.v20110425'>
      <update id='org.eclipse.ui.intro' range='[0.0.0,3.4.100.v20110425)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin_name' value='Welcome Framework'/>
        <property name='df_LT.provider_name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider_name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro' version='3.4.100.v20110425'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.intro' version='3.4.100.v20110425'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.html' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.model.loader' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.model.url' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.model.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.model.viewer' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.parts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.impl.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro.config' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro.contentproviders' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='12'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help.base' range='[3.5.0,4.0.0)' optional='true'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='3.4.200'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.dom' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.transform.stream' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.intro' version='3.4.100.v20110425'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.intro; singleton:=true&#xA;Bundle-Version: 3.4.100.v20110425
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.intro.universal' version='3.2.500.v20110510'>
      <update id='org.eclipse.ui.intro.universal' range='[0.0.0,3.2.500.v20110510)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.plugin_name' value='Universal Welcome'/>
        <property name='df_LT.provider_name' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%plugin_name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%provider_name'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.intro.universal' version='3.2.500.v20110510'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.intro.universal' version='3.2.500.v20110510'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.universal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.universal.contentdetect' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro.universal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro.universal' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.intro' range='[3.4.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.intro.universal' version='3.2.500.v20110510'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.intro.universal;singleton:=true&#xA;Bundle-Version: 3.2.500.v20110510
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'>
      <update id='org.eclipse.ui.navigator' range='[0.0.0,3.5.101.v20120106-1355)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Common Navigator View'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.extensions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.filters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.framelist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.sorters' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.navigator' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.navigator' version='3.5.101.v20120106-1355'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.navigator; singleton:=true&#xA;Bundle-Version: 3.5.101.v20120106-1355
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.navigator.resources' version='3.4.300.v20110928-1505'>
      <update id='org.eclipse.ui.navigator.resources' range='[0.0.0,3.4.300.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Navigator Workbench Components'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='10'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.navigator.resources' version='3.4.300.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.navigator.resources' version='3.4.300.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.resources.workbench' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.navigator.workingsets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.navigator.resources' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='10'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.navigator' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views.properties.tabbed' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.core.refactoring' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ltk.ui.refactoring' range='[3.5.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.navigator.resources' version='3.4.300.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.navigator.resources; singleton:=true&#xA;Bundle-Version: 3.4.300.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.net' version='1.2.100.v20111208-1155'>
      <update id='org.eclipse.ui.net' range='[0.0.0,1.2.100.v20111208-1155)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.PLUGIN_NAME' value='Internet Connection Management UI'/>
        <property name='df_LT.PLUGIN_PROVIDER' value='Eclipse.org'/>
        <property name='org.eclipse.equinox.p2.name' value='%PLUGIN_NAME'/>
        <property name='org.eclipse.equinox.p2.provider' value='%PLUGIN_PROVIDER'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.net' version='1.2.100.v20111208-1155'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.net' version='1.2.100.v20111208-1155'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.net' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.net.auth' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='[1.0.0,2.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.net' version='1.2.100.v20111208-1155'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.net; singleton:=true&#xA;Bundle-Version: 1.2.100.v20111208-1155
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.presentations.r21' version='3.2.200.I20100517-1500'>
      <update id='org.eclipse.ui.presentations.r21' range='[0.0.0,3.2.200.I20100517-1500)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='R21 Presentation Plug-in'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.presentations.r21' version='3.2.200.I20100517-1500'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.presentations.r21' version='3.2.200.I20100517-1500'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.r21' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.r21.widgets' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.presentations.r21' version='3.2.200.I20100517-1500'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.presentations.r21; singleton:=true&#xA;Bundle-Version: 3.2.200.I20100517-1500
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.views' version='3.6.0.v20110928-1505'>
      <update id='org.eclipse.ui.views' range='[0.0.0,3.6.0.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Views'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.contentoutline' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.contentoutline' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.views' version='3.6.0.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.views; singleton:=true&#xA;Bundle-Version: 3.6.0.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'>
      <update id='org.eclipse.ui.views.properties.tabbed' range='[0.0.0,3.5.200.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.Plugin.providerName' value='Eclipse.org'/>
        <property name='df_LT.Plugin.name' value='Tabbed Properties View'/>
        <property name='org.eclipse.equinox.p2.name' value='%Plugin.name'/>
        <property name='org.eclipse.equinox.p2.provider' value='%Plugin.providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='8'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed.l10n' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.views.properties.tabbed.view' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views.properties.tabbed' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.views' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.3.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.views.properties.tabbed' version='3.5.200.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.views.properties.tabbed;singleton:=true&#xA;Bundle-Version: 3.5.200.v20110928-1505
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.win32' version='3.2.200.v20110928-1505' singleton='false'>
      <update id='org.eclipse.ui.win32' range='[0.0.0,3.2.200.v20110928-1505)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Eclipse UI Win32 Enhancements'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment-win32'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editorsupport.win32' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ui.ide' version='3.2.200.v20110928-1505'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.ide' range='[3.2.0,4.0.0)'/>
      </requires>
      <filter>
        (osgi.ws=win32)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.win32' version='3.2.200.v20110928-1505'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.win32&#xA;Bundle-Version: 3.2.200.v20110928-1505&#xA;Fragment-Host: org.eclipse.ui.ide;bundle-version=&quot;[3.2.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'>
      <update id='org.eclipse.ui.workbench' range='[0.0.0,3.7.1.v20120104-1859)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Workbench'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='81'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
        <provided namespace='java.package' name='org.eclipse.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.branding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.databinding' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.fieldassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.about' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.actions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.activities.ws' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.browser' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.commands' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.contexts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.decorators' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dialogs' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.dnd' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.editorsupport' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.expressions' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.handlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.help' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.keys.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.layout' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.misc' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.classic' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.defaultpresentation' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.presentations.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.application' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.provisional.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.quickaccess' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.registry' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.tweaklets' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.util' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.wizards.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.intro' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.keys' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.menus' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.part' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.plugin' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.presentations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.progress' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.services' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.splash' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.statushandlers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.swt' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.testing' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.themes' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.wizards' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='13'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.6.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.help' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.swt' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.databinding' range='[1.3.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.property' range='[1.2.0,2.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.databinding.observable' range='[1.2.0,2.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
        <required namespace='java.package' name='com.ibm.icu.util' range='0.0.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench' version='3.7.1.v20120104-1859'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench; singleton:=true&#xA;Bundle-Version: 3.7.1.v20120104-1859
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench.compatibility' version='3.2.100.I20110413-1600' singleton='false'>
      <update id='org.eclipse.ui.workbench.compatibility' range='[0.0.0,3.2.100.I20110413-1600)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.fragmentName' value='Workbench Compatibility'/>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='fragment-compatibility'/>
      </properties>
      <provides size='5'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.compatibility' version='3.2.100.I20110413-1600'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench.compatibility' version='3.2.100.I20110413-1600'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.ui.workbench' version='3.2.100.I20110413-1600'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.ui.workbench' range='[3.0.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.resources' range='[3.2.0,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench.compatibility' version='3.2.100.I20110413-1600'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench.compatibility&#xA;Bundle-Version: 3.2.100.I20110413-1600&#xA;Fragment-Host: org.eclipse.ui.workbench;bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
          <instruction key='zipped'>
            true
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'>
      <update id='org.eclipse.ui.workbench.texteditor' range='[0.0.0,3.7.0.v20110928-1504)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Text Editor Framework'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='16'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
        <provided namespace='osgi.bundle' name='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
        <provided namespace='java.package' name='org.eclipse.ui.contentassist' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.quickdiff.compare.equivalence' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.rulers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.internal.texteditor.spelling' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.link' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.quickdiff' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.rulers' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.spelling' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.ui.texteditor.templates' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.compare.core' range='[3.5.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.expressions' range='[3.4.100,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.jface.text' range='[3.7.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.5.0,4.0.0)'/>
        <required namespace='java.package' name='com.ibm.icu.text' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.ui.workbench.texteditor' version='3.7.0.v20110928-1504'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.ui.workbench.texteditor; singleton:=true&#xA;Bundle-Version: 3.7.0.v20110928-1504
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.configurator' version='3.3.100.v20100512'>
      <update id='org.eclipse.update.configurator' range='[0.0.0,3.3.100.v20100512)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Install/Update Configurator'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='7'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
        <provided namespace='java.package' name='org.eclipse.update.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.configurator' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.configurator.branding' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='6'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.osgi' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.configurator' version='3.3.100.v20100512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.configurator; singleton:=true&#xA;Bundle-Version: 3.3.100.v20100512
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.core' version='3.2.500.v20110330'>
      <update id='org.eclipse.update.core' range='[0.0.0,3.2.500.v20110330)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Install/Update Core'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='20'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core' version='3.2.500.v20110330'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.core' version='3.2.500.v20110330'/>
        <provided namespace='java.package' name='org.eclipse.update.configuration' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.core.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.core' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.core.connection' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.jarprocessor' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.mirror' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.provisional' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.verifier' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.operations' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.search' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.standalone' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='7'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.4.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.core.net' range='[1.0.0,2.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.core' version='3.2.500.v20110330'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.core; singleton:=true&#xA;Bundle-Version: 3.2.500.v20110330
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.core.win32' version='3.2.200.v20100512' singleton='false'>
      <update id='org.eclipse.update.core.win32' range='[0.0.0,3.2.200.v20100512)' severity='0'/>
      <properties size='3'>
        <property name='org.eclipse.equinox.p2.name' value='%fragmentNameWin'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='4'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.core.win32' version='3.2.200.v20100512'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.core.win32' version='3.2.200.v20100512'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='osgi.fragment' name='org.eclipse.update.core' version='3.2.200.v20100512'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.eclipse.update.core' range='[3.0.0,4.0.0)'/>
      </requires>
      <filter>
        (osgi.os=win32)
      </filter>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.core.win32' version='3.2.200.v20100512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.core.win32&#xA;Bundle-Version: 3.2.200.v20100512&#xA;Fragment-Host: org.eclipse.update.core;bundle-version=&quot;[3.0.0,4.0.0)&quot;
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.scheduler' version='3.2.300.v20100512'>
      <update id='org.eclipse.update.scheduler' range='[0.0.0,3.2.300.v20100512)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Automatic Updates Scheduler'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='6'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.scheduler' version='3.2.300.v20100512'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.scheduler' version='3.2.300.v20100512'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.scheduler' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.scheduler.preferences' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='5'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.core' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.ui' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.1.100,4.0.0)'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.scheduler' version='3.2.300.v20100512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.scheduler; singleton:=true&#xA;Bundle-Version: 3.2.300.v20100512
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.eclipse.update.ui' version='3.2.300.v20100512'>
      <update id='org.eclipse.update.ui' range='[0.0.0,3.2.300.v20100512)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.providerName' value='Eclipse.org'/>
        <property name='df_LT.pluginName' value='Install/Update UI'/>
        <property name='org.eclipse.equinox.p2.name' value='%pluginName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='13'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.eclipse.update.ui' version='3.2.300.v20100512'/>
        <provided namespace='osgi.bundle' name='org.eclipse.update.ui' version='3.2.300.v20100512'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.model' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.parts' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.preferences' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.properties' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.security' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.views' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.internal.ui.wizards' version='0.0.0'/>
        <provided namespace='java.package' name='org.eclipse.update.ui' version='0.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='8'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui' range='[3.2.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.core' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='[3.1.0,4.0.0)'/>
        <required namespace='osgi.bundle' name='org.eclipse.ui.forms' range='[3.2.0,4.0.0)'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
        <required namespace='java.package' name='org.w3c.dom' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.eclipse.update.ui' version='3.2.300.v20100512'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.eclipse.update.ui; singleton:=true&#xA;Bundle-Version: 3.2.300.v20100512
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.mortbay.jetty.server' version='6.1.23.v201012071420' singleton='false'>
      <update id='org.mortbay.jetty.server' range='[0.0.0,6.1.23.v201012071420)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Jetty Server'/>
        <property name='org.eclipse.equinox.p2.description' value='Jetty server core'/>
        <property name='org.eclipse.equinox.p2.provider' value='Mort Bay Consulting'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://jetty.mortbay.org'/>
      </properties>
      <provides size='17'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
        <provided namespace='osgi.bundle' name='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
        <provided namespace='java.package' name='org.mortbay.jetty' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io.nio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.servlet.jetty' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.bio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.security' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.webapp' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.xml' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.nio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.handler' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.resource' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.servlet' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.io.bio' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.jetty.deployer' version='6.1.23'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='17'>
        <required namespace='java.package' name='org.mortbay.servlet' range='6.1.0'/>
        <required namespace='java.package' name='javax.servlet' range='2.5.0'/>
        <required namespace='java.package' name='org.mortbay.jetty.handler.management' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.http' range='2.5.0'/>
        <required namespace='java.package' name='javax.net.ssl' range='0.0.0'/>
        <required namespace='java.package' name='org.apache.jasper.servlet' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.resources' range='2.5.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet.jsp' range='0.0.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='org.mortbay.component' range='6.1.0'/>
        <required namespace='java.package' name='org.xml.sax.helpers' range='0.0.0'/>
        <required namespace='java.package' name='org.mortbay.util.ajax' range='6.1.0'/>
        <required namespace='java.package' name='org.mortbay.util' range='6.1.0'/>
        <required namespace='java.package' name='javax.security.cert' range='0.0.0'/>
        <required namespace='java.package' name='org.xml.sax' range='0.0.0'/>
        <required namespace='java.package' name='org.mortbay.thread' range='6.1.0'/>
        <required namespace='java.package' name='org.mortbay.log' range='6.1.0'/>
        <required namespace='java.package' name='javax.xml.parsers' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.mortbay.jetty.server' version='6.1.23.v201012071420'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.mortbay.jetty.server&#xA;Bundle-Version: 6.1.23.v201012071420
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.mortbay.jetty.util' version='6.1.23.v201012071420' singleton='false'>
      <update id='org.mortbay.jetty.util' range='[0.0.0,6.1.23.v201012071420)' severity='0'/>
      <properties size='4'>
        <property name='org.eclipse.equinox.p2.name' value='Jetty Utilities'/>
        <property name='org.eclipse.equinox.p2.description' value='Utility classes for Jetty'/>
        <property name='org.eclipse.equinox.p2.provider' value='Mort Bay Consulting'/>
        <property name='org.eclipse.equinox.p2.doc.url' value='http://jetty.mortbay.org'/>
      </properties>
      <provides size='9'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
        <provided namespace='osgi.bundle' name='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
        <provided namespace='java.package' name='org.mortbay.log' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.util.ajax' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.servlet' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.thread' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.util' version='6.1.23'/>
        <provided namespace='java.package' name='org.mortbay.component' version='6.1.23'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
      </provides>
      <requires size='3'>
        <required namespace='java.package' name='org.slf4j' range='1.3.0' optional='true' greedy='false'/>
        <required namespace='java.package' name='javax.servlet' range='0.0.0'/>
        <required namespace='java.package' name='javax.servlet.http' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.mortbay.jetty.util' version='6.1.23.v201012071420'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.mortbay.jetty.util&#xA;Bundle-Version: 6.1.23.v201012071420
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.core' version='2.3.0.v20110329' singleton='false'>
      <update id='org.sat4j.core' range='[0.0.0,2.3.0.v20110329)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Core'/>
        <property name='df_LT.providerName' value='CRIL CNRS UMR 8188 - Universite d&apos;Artois'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='19'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.core' version='2.3.0.v20110329'/>
        <provided namespace='osgi.bundle' name='org.sat4j.core' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.core' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.card' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.constraints.cnf' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.core' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.learning' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.orders' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.minisat.restarts' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.opt' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.reader' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.specs' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.tools' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.tools.xplain' version='2.3.0.v20110329'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.core' version='2.3.0.v20110329'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.core&#xA;Bundle-Version: 2.3.0.v20110329
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='org.sat4j.pb' version='2.3.0.v20110329' singleton='false'>
      <update id='org.sat4j.pb' range='[0.0.0,2.3.0.v20110329)' severity='0'/>
      <properties size='5'>
        <property name='df_LT.bundleName' value='SAT4J Pseudo'/>
        <property name='df_LT.providerName' value='CRIL CNRS UMR 8188 - Universite d&apos;Artois'/>
        <property name='org.eclipse.equinox.p2.name' value='%bundleName'/>
        <property name='org.eclipse.equinox.p2.provider' value='%providerName'/>
        <property name='org.eclipse.equinox.p2.bundle.localization' value='plugin'/>
      </properties>
      <provides size='11'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='org.sat4j.pb' version='2.3.0.v20110329'/>
        <provided namespace='osgi.bundle' name='org.sat4j.pb' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.constraints.pb' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.core' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.orders' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.reader' version='2.3.0.v20110329'/>
        <provided namespace='java.package' name='org.sat4j.pb.tools' version='2.3.0.v20110329'/>
        <provided namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.localization' name='df_LT' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='osgi.bundle' name='org.sat4j.core' range='0.0.0'/>
      </requires>
      <artifacts size='1'>
        <artifact classifier='osgi.bundle' id='org.sat4j.pb' version='2.3.0.v20110329'/>
      </artifacts>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='1'>
          <instruction key='manifest'>
            Bundle-SymbolicName: org.sat4j.pb&#xA;Bundle-Version: 2.3.0.v20110329
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.org.eclipse.update.feature.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.org.eclipse.update.feature.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='feature' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <filter>
        (org.eclipse.update.install.features=true)
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            installFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
          <instruction key='uninstall'>
            uninstallFeature(feature:${artifact},featureId:default,featureVersion:default)
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.osgi.bundle.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.osgi.bundle.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='0.0.0' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>

          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:4);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='tooling.source.default' version='1.0.0' singleton='false'>
      <hostRequirements size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='tooling.source.default' version='1.0.0'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='1'>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='source' range='0.0.0' optional='true' multiple='true' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='install'>
            addSourceBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            removeSourceBundle(bundle:${artifact})
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.configuration' version='1.0.0' singleton='false'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.configuration' version='1.0.0'/>
      </provides>
      <filter>
        (!(osgi.os=macosx))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:osgi.instance.area.default,propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:osgi.instance.area.default,propValue:@user.home/workspace);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher' version='1.2.0.v20110502' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher' version='1.2.0.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher' range='[1.2.0.v20110502,1.2.0.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:-startup);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:-startup);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
        <property name='org.eclipse.pde.build.default' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.equinox.launcher.win32.win32.x86' version='1.1.100.v20110502'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='tooling' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.launcher.win32.win32.x86' range='[1.1.100.v20110502,1.1.100.v20110502]' greedy='false'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact});
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact});
          </instruction>
          <instruction key='unconfigure'>
            removeProgramArg(programArg:--launcher.library);removeProgramArg(programArg:@artifact);
          </instruction>
          <instruction key='configure'>
            addProgramArg(programArg:--launcher.library);addProgramArg(programArg:@artifact);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.platform.ide.config.win32.win32.x86' version='3.7.2.M20120208-0800' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.win32.win32.x86' version='3.7.2.M20120208-0800'/>
        <provided namespace='toolingorg.eclipse.platform.ide' name='org.eclipse.platform.ide.config' version='3.7.2.M20120208-0800'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            setProgramProperty(propName:eclipse.buildId,propValue:);setProgramProperty(propName:osgi.splashPath,propValue:);setProgramProperty(propName:eclipse.application,propValue:);setProgramProperty(propName:eclipse.product,propValue:);setProgramProperty(propName:osgi.bundles.defaultStartLevel,propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:eclipse.buildId,propValue:M20120208-0800);setProgramProperty(propName:osgi.splashPath,propValue:platform${#58}/base/plugins/org.eclipse.platform);setProgramProperty(propName:eclipse.application,propValue:org.eclipse.ui.ide.workbench);setProgramProperty(propName:eclipse.product,propValue:org.eclipse.platform.ide);setProgramProperty(propName:osgi.bundles.defaultStartLevel,propValue:4);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingorg.eclipse.platform.ide.configuration' version='3.7.2.M20120208-0800'>
      <provides size='1'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.configuration' version='3.7.2.M20120208-0800'/>
      </provides>
      <requires size='126'>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.solaris.sparc' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.solaris.sparc' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.aix.ppc' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.carbon.macosx.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.linux.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.win32.win32.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.cocoa.macosx.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.linux.s390x' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.win32.win32.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.linux.s390x' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.cocoa.macosx.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.aix.ppc64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.hpux.ia64_32' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.aix.ppc64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.aix.ppc' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.solaris.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.cocoa.macosx.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.hpux.ia64_32' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.win32.win32.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.linux.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.cocoa.macosx.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.linux.s390' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.linux.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.linux.s390' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.gtk.linux.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.win32.win32.x86_64' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppcorg.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.equinox.common' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.config.carbon.macosx.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcocoa.macosx.x86_64org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=macosx)(osgi.ws=cocoa))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.gtk.solaris.x86' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.core.runtime' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.sparcorg.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=sparc)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.x86_64org.eclipse.equinox.simpleconfigurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingcarbon.macosx.x86org.eclipse.update.configurator' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=macosx)(osgi.ws=carbon))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86_64org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86_64)(osgi.os=win32)(osgi.ws=win32))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.solaris.x86org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=x86)(osgi.os=solaris)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.hpux.ia64_32org.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ia64_32)(osgi.os=hpux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.linux.s390xorg.eclipse.equinox.event' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=s390x)(osgi.os=linux)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.equinox.p2.reconciler.dropins' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
        <required namespace='org.eclipse.equinox.p2.iu' name='toolinggtk.aix.ppc64org.eclipse.equinox.ds' range='[3.7.2.M20120208-0800,3.7.2.M20120208-0800]'>
          <filter>
            (&amp;(osgi.arch=ppc64)(osgi.os=aix)(osgi.ws=gtk))
          </filter>
        </required>
      </requires>
      <touchpoint id='null' version='0.0.0'/>
    </unit>
    <unit id='toolingorg.eclipse.platform.ide.ini.win32.win32.x86' version='3.7.2.M20120208-0800' singleton='false'>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingorg.eclipse.platform.ide.ini.win32.win32.x86' version='3.7.2.M20120208-0800'/>
        <provided namespace='toolingorg.eclipse.platform.ide' name='org.eclipse.platform.ide.ini' version='3.7.2.M20120208-0800'/>
      </provides>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='org.eclipse.equinox.p2.osgi' version='1.0.0'/>
      <touchpointData size='1'>
        <instructions size='2'>
          <instruction key='unconfigure'>
            removeJvmArg(jvmArg:-Xms40m);removeJvmArg(jvmArg:-Xmx384m);removeProgramArg(programArg:-showsplash);removeProgramArg(programArg:org.eclipse.platform);removeProgramArg(programArg:--launcher.XXMaxPermSize);removeProgramArg(programArg:256m);removeProgramArg(programArg:--launcher.defaultAction);removeProgramArg(programArg:openFile);
          </instruction>
          <instruction key='configure'>
            addJvmArg(jvmArg:-Xms40m);addJvmArg(jvmArg:-Xmx384m);addProgramArg(programArg:-showsplash);addProgramArg(programArg:org.eclipse.platform);addProgramArg(programArg:--launcher.XXMaxPermSize);addProgramArg(programArg:256m);addProgramArg(programArg:--launcher.defaultAction);addProgramArg(programArg:openFile);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.core.runtime' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0.v20110110'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.core.runtime' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.core.runtime' range='3.7.0.v20110110'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.equinox.common' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0.v20110523'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.common' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.common' range='3.6.0.v20110523'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.equinox.ds' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.ds' range='1.3.1.R37x_v20110701'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.ds' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.ds' range='1.3.1.R37x_v20110701'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.equinox.event' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.2.100.v20110502'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.event' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.event' range='1.2.100.v20110502'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:2);markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.equinox.p2.reconciler.dropins' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' range='1.1.100.v20110815-1419'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.p2.reconciler.dropins' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.p2.reconciler.dropins' range='1.1.100.v20110815-1419'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.equinox.simpleconfigurator' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.0.200.v20110815-1438'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.equinox.simpleconfigurator' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.equinox.simpleconfigurator' range='1.0.200.v20110815-1438'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setStartLevel(startLevel:-1);markStarted(started: false);
          </instruction>
          <instruction key='configure'>
            setStartLevel(startLevel:1);markStarted(started: true);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
    <unit id='toolingwin32.win32.x86org.eclipse.update.configurator' version='3.7.2.M20120208-0800' singleton='false'>
      <hostRequirements size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='3.3.100.v20100512'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </hostRequirements>
      <properties size='1'>
        <property name='org.eclipse.equinox.p2.type.fragment' value='true'/>
      </properties>
      <provides size='2'>
        <provided namespace='org.eclipse.equinox.p2.iu' name='toolingwin32.win32.x86org.eclipse.update.configurator' version='3.7.2.M20120208-0800'/>
        <provided namespace='org.eclipse.equinox.p2.flavor' name='toolingwin32.win32.x86' version='1.0.0'/>
      </provides>
      <requires size='2'>
        <required namespace='osgi.bundle' name='org.eclipse.update.configurator' range='3.3.100.v20100512'/>
        <required namespace='org.eclipse.equinox.p2.eclipse.type' name='bundle' range='[1.0.0,2.0.0)' greedy='false'/>
      </requires>
      <filter>
        (&amp;(osgi.arch=x86)(osgi.os=win32)(osgi.ws=win32))
      </filter>
      <touchpoint id='null' version='0.0.0'/>
      <touchpointData size='1'>
        <instructions size='4'>
          <instruction key='install'>
            installBundle(bundle:${artifact})
          </instruction>
          <instruction key='uninstall'>
            uninstallBundle(bundle:${artifact})
          </instruction>
          <instruction key='unconfigure'>
            setProgramProperty(propName:org.eclipse.update.reconcile, propValue:);
          </instruction>
          <instruction key='configure'>
            setProgramProperty(propName:org.eclipse.update.reconcile, propValue:false);
          </instruction>
        </instructions>
      </touchpointData>
    </unit>
  </units>
  <iusProperties size='190'>
    <iuProperties id='org.eclipse.platform.ide' version='3.7.2.M20120208-0800'>
      <properties size='2'>
        <property name='org.eclipse.equinox.p2.internal.inclusion.rules' value='STRICT'/>
        <property name='org.eclipse.equinox.p2.type.root' value='true'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.platform_root' version='3.7.2.v20120207-1839-9gF7UHPDFxGjd-PqDr2jX_4yKaumkoHTz04_q-q'>
      <properties size='1'>
        <property name='unzipped|@artifact|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/epl-v10.html|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/notice.html|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/.eclipseproduct|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/readme|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/readme/readme_eclipse.html|'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp.configuration_root.win32.win32.x86' version='1.0.0.M20120208-0800'>
      <properties size='1'>
        <property name='unzipped|@artifact|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/eclipse.exe|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/eclipsec.exe|'/>
      </properties>
    </iuProperties>
    <iuProperties id='org.eclipse.rcp_root' version='3.7.2.v20120120-1424-9DB5FmnFq5JCf1UA38R-kz0S0272'>
      <properties size='1'>
        <property name='unzipped|@artifact|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse' value='/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/readme|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/readme/readme_eclipse.html|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/.eclipseproduct|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/notice.html|/builds/M201202080800/src/M20120208-0800/p2temp/equinox.p2.build/platform.install.win32.win32.x86/eclipse/epl-v10.html|'/>
      </properties>
    </iuProperties>
  </iusProperties>
</profile>
